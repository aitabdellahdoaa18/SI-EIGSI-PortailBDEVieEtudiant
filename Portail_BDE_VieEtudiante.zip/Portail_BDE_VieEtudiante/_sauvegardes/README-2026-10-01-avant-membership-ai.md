# Portail BDE — Vie étudiante

Première version de l’interface React/Vite du Portail BDE. La page d’accueil affiche les événements publiés depuis Supabase après l’application de la migration, du jeu de test et la configuration du projet hébergé.

## Prérequis

- Node.js (version LTS)
- npm, fourni avec Node.js

## Installer et lancer sur Windows

Dans un terminal ouvert à la racine du projet :

```powershell
npm.cmd install
npm.cmd run dev
```

Vite affichera une adresse locale dans le terminal, généralement <http://localhost:5173/>. Ouvre cette adresse dans ton navigateur.

Pour vérifier qu’une version de production peut être construite :

```powershell
npm.cmd run build
```

Pour prévisualiser cette version construite :

```powershell
npm.cmd run preview
```

> Sur cette installation de Windows, `npm` est bloqué par la règle d’exécution PowerShell. Utilise `npm.cmd` comme dans les commandes ci-dessus ; il n’est pas nécessaire de modifier cette règle.

## Créer la base de test dans Supabase

1. Crée ou ouvre un projet Supabase hébergé.
2. Dans son **SQL Editor**, exécute les migrations dans l’ordre : d’abord `supabase/migrations/20261001120000_create_portail_schema.sql`, puis `supabase/migrations/20261001170000_enable_backlog_workflows.sql`.
3. Exécute ensuite `supabase/seed.sql` pour insérer les comptes fictifs, clubs, événements, inscriptions et demandes de validation de démonstration. Les deux événements publiés seront visibles ; la demande après 18 h restera privée en attente de validation.
4. Copie `.env.example` vers `.env.local` à la racine du projet.
5. Renseigne `VITE_SUPABASE_URL` et `VITE_SUPABASE_ANON_KEY` avec les valeurs publiques de ton projet Supabase, puis redémarre Vite avec `npm.cmd run dev`.
6. Crée un compte étudiant depuis le formulaire de l’application. Un nouveau compte reçoit toujours le rôle étudiant. Pour tester les écrans BDE ou administration, crée le compte, confirme son adresse si Supabase le demande, puis attribue son rôle dans le SQL Editor du projet en mettant à jour sa ligne dans `public.utilisateur`.

La page d’accueil lit les événements publiés dans la table `evenement`. Les migrations protègent les tables avec RLS et exposent les opérations événementielles par des fonctions qui contrôlent le rôle. La génération d’affiches, les courriels de confirmation et le paiement des cotisations nécessitent encore le choix et la configuration des services externes.

Ne mets jamais une clé secrète `service_role` dans `.env.local` : les variables `VITE_` sont intégrées dans l’interface et visibles dans le navigateur. Les noms et adresses du jeu de test sont fictifs et utilisent le domaine réservé `example.test`.

## Structure de départ

- `src/` — interface React.
- `src/pages/` — pages de l’application ; `Events.jsx` affiche les événements publiés et `Hello.jsx` reste un exemple de test.
- `src/components/` — composants réutilisables.
- `src/lib/` — connexion Supabase et fonctions partagées.
- `supabase/migrations/` — scripts SQL de création et d’évolution de la base.
- `supabase/seed.sql` — données fictives de démonstration.
