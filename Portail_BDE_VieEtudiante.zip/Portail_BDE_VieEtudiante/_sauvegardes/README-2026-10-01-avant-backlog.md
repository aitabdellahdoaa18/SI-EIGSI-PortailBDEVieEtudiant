# Portail BDE — Vie étudiante

Première version de l’interface React/Vite du Portail BDE. La page d’accueil affiche les événements publiés depuis Supabase après l’application de la migration, du jeu de test et la configuration du projet hébergé.

## Prérequis

- Node.js (version LTS)
- npm, fourni avec Node.js

## Installer et lancer sur Windows

Dans un terminal ouvert à la racine du projet :

```powershell
npm.cmd install
npm.cmd run dev
```

Vite affichera une adresse locale dans le terminal, généralement <http://localhost:5173/>. Ouvre cette adresse dans ton navigateur.

Pour vérifier qu’une version de production peut être construite :

```powershell
npm.cmd run build
```

Pour prévisualiser cette version construite :

```powershell
npm.cmd run preview
```

> Sur cette installation de Windows, `npm` est bloqué par la règle d’exécution PowerShell. Utilise `npm.cmd` comme dans les commandes ci-dessus ; il n’est pas nécessaire de modifier cette règle.

## Créer la base de test dans Supabase

1. Crée ou ouvre un projet Supabase hébergé.
2. Dans son **SQL Editor**, exécute le contenu de `supabase/migrations/20261001120000_create_portail_schema.sql`.
3. Exécute ensuite le contenu de `supabase/seed.sql` pour insérer les comptes fictifs, clubs, événements, inscriptions et demandes de validation de démonstration. Les deux événements publiés seront visibles ; la demande après 18 h restera privée en attente de validation.
4. Copie `.env.example` vers `.env.local` à la racine du projet.
5. Renseigne `VITE_SUPABASE_URL` et `VITE_SUPABASE_ANON_KEY` avec les valeurs publiques de ton projet Supabase, puis redémarre Vite avec `npm.cmd run dev`.

La page d’accueil lit les événements publiés dans la table `evenement`. Les règles RLS de départ autorisent uniquement la lecture publique de ces événements ; les autres tables n’ont pas encore de règles d’accès pour les opérations utilisateur.

Ne mets jamais une clé secrète `service_role` dans `.env.local` : les variables `VITE_` sont intégrées dans l’interface et visibles dans le navigateur. Les noms et adresses du jeu de test sont fictifs et utilisent le domaine réservé `example.test`.

## Structure de départ

- `src/` — interface React.
- `src/pages/` — pages de l’application ; `Events.jsx` affiche les événements publiés et `Hello.jsx` reste un exemple de test.
- `src/components/` — composants réutilisables.
- `src/lib/` — connexion Supabase et fonctions partagées.
- `supabase/migrations/` — scripts SQL de création et d’évolution de la base.
- `supabase/seed.sql` — données fictives de démonstration.
