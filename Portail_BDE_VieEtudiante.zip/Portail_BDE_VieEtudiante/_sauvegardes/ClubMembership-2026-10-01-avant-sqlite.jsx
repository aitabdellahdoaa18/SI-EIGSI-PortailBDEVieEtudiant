import { useEffect, useState } from 'react';
import { getClubs, getMyMemberships, requestMembership } from '../lib/portalData.js';

const amountLabels = { annuelle: '200 MAD / année', cycle: '300 MAD / cycle' };

export default function ClubMembership() {
  const [clubs, setClubs] = useState([]);
  const [memberships, setMemberships] = useState([]);
  const [error, setError] = useState('');
  const [feedback, setFeedback] = useState('');
  const [busy, setBusy] = useState(false);
  const [plan, setPlan] = useState('annuelle');

  async function refresh() {
    try {
      const [clubRows, membershipRows] = await Promise.all([getClubs(), getMyMemberships()]);
      setClubs(clubRows);
      setMemberships(membershipRows);
      setError('');
    } catch {
      setError('Impossible de charger les clubs ou tes demandes. Vérifie la migration Supabase.');
    }
  }

  useEffect(() => { refresh(); }, []);

  async function handleRequest(event) {
    event.preventDefault();
    const form = event.currentTarget;
    const values = new FormData(form);
    setError('');
    setFeedback('');
    setBusy(true);
    try {
      await requestMembership({
        clubId: Number(values.get('club')),
        plan,
        cycle: plan === 'cycle' ? String(values.get('cycle') || '') || null : null,
      });
      form.reset();
      setFeedback('Demande enregistrée. Règle la cotisation en dehors du portail ; le BDE confirmera le paiement avant activation.');
      await refresh();
    } catch (requestError) {
      setError(requestError.message?.includes('existe déjà')
        ? 'Une demande existe déjà pour cette formule et ce club.'
        : 'La demande n’a pas pu être enregistrée.');
    } finally {
      setBusy(false);
    }
  }

  return (
    <section className="portal-panel">
      <div className="portal-panel__heading"><div><p className="portal-eyebrow">ASSOCIATIONS ÉTUDIANTES</p><h2>Adhérer à un club</h2></div></div>
      <p className="portal-empty">Cotisation annuelle : 200 MAD. Cotisation par cycle (Prépa ou Ingénieur) : 300 MAD. Le règlement se fait hors du portail.</p>
      <form className="portal-form membership-form" onSubmit={handleRequest}>
        <label>Club<select name="club" required defaultValue=""><option value="" disabled>Choisis un club</option>{clubs.map((club) => <option key={club.id_club} value={club.id_club}>{club.nom}</option>)}</select></label>
        <label>Formule<select name="plan" required value={plan} onChange={(event) => setPlan(event.target.value)}><option value="annuelle">Année — 200 MAD</option><option value="cycle">Cycle — 300 MAD</option></select></label>
        {plan === 'cycle' && <label>Cycle<select name="cycle" required defaultValue=""><option value="" disabled>Choisis ton cycle</option><option value="prepa">Prépa</option><option value="ingenieur">Ingénieur</option></select></label>}
        <button className="button button--primary" type="submit" disabled={busy}>{busy ? 'Envoi…' : 'Demander l’adhésion'}</button>
      </form>
      {feedback && <p className="portal-feedback" role="status">{feedback}</p>}
      {error && <p className="portal-feedback portal-feedback--error" role="alert">{error}</p>}
      <h3 className="membership-heading">Mes demandes</h3>
      <div className="portal-list">{memberships.map((membership) => <div className="portal-row" key={membership.id_adhesion}><div><strong>{membership.club?.nom}</strong><p>{amountLabels[membership.plan_cotisation]}{membership.cycle_etude ? ` · ${membership.cycle_etude === 'prepa' ? 'Prépa' : 'Ingénieur'}` : ''}</p></div><span className={`portal-status ${membership.statut === 'active' ? 'portal-status--good' : 'portal-status--pending'}`}>{membership.statut === 'active' ? 'Cotisation confirmée' : membership.statut === 'en_attente_paiement' ? 'Paiement à confirmer' : membership.statut}</span></div>)}{memberships.length === 0 && <p className="portal-empty">Aucune demande pour le moment.</p>}</div>
    </section>
  );
}
