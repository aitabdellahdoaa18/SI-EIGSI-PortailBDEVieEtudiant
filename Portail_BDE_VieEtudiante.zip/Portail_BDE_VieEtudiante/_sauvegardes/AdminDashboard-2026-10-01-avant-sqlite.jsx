import { useCallback, useEffect, useState } from 'react';
import { decideValidation, getAdminStatistics, getPendingValidations } from '../lib/portalData.js';
import './Portal.css';

const dateFormatter = new Intl.DateTimeFormat('fr-FR', {
  dateStyle: 'medium',
  timeStyle: 'short',
  timeZone: 'Europe/Paris',
});

export default function AdminDashboard() {
  const [requests, setRequests] = useState([]);
  const [statistics, setStatistics] = useState(null);
  const [feedback, setFeedback] = useState('');
  const [error, setError] = useState('');

  const refresh = useCallback(async () => {
    try {
      const [pending, totals] = await Promise.all([getPendingValidations(), getAdminStatistics()]);
      setRequests(pending);
      setStatistics(totals);
      setError('');
    } catch {
      setError('Impossible de charger les demandes ou les statistiques. Vérifie les droits du compte administration.');
    }
  }, []);

  useEffect(() => { refresh(); }, [refresh]);

  async function handleDecision(id, decision) {
    setError('');
    setFeedback('');
    try {
      await decideValidation(id, decision);
      setFeedback(decision === 'valide' ? 'Demande approuvée : l’événement est publié.' : 'Demande refusée.');
      await refresh();
    } catch {
      setError('La décision n’a pas pu être enregistrée.');
    }
  }

  return (
    <div>
      <section className="portal-panel">
        <div className="portal-panel__heading">
          <div><p className="portal-eyebrow">ESPACE ADMINISTRATION</p><h2>Demandes à valider</h2></div>
          <button className="button button--quiet" type="button" onClick={refresh}>Actualiser</button>
        </div>
        {feedback && <p className="portal-feedback" role="status">{feedback}</p>}
        {error && <p className="portal-feedback portal-feedback--error" role="alert">{error}</p>}
        <div className="portal-list">
          {requests.map((request) => (
            <article className="portal-row" key={request.id_validation}>
              <div>
                <strong>{request.evenement?.titre}</strong>
                <p>{request.evenement?.lieu} · {request.evenement?.date_debut && dateFormatter.format(new Date(request.evenement.date_debut))}</p>
                <p>{request.commentaire}</p>
              </div>
              <div className="portal-row__actions">
                <button className="button button--approve button--small" type="button" onClick={() => handleDecision(request.id_validation, 'valide')}>Valider</button>
                <button className="button button--reject button--small" type="button" onClick={() => handleDecision(request.id_validation, 'refuse')}>Refuser</button>
              </div>
            </article>
          ))}
          {requests.length === 0 && !error && <p className="portal-empty">Aucune demande en attente.</p>}
        </div>
      </section>

      <section className="portal-panel">
        <div className="portal-panel__heading">
          <div><p className="portal-eyebrow">SUIVI</p><h2>Statistiques de participation</h2></div>
        </div>
        {statistics ? (
          <div className="portal-stats">
            <article className="portal-stat"><span>Événements</span><strong>{statistics.events}</strong></article>
            <article className="portal-stat"><span>Inscriptions</span><strong>{statistics.registrations}</strong></article>
            <article className="portal-stat"><span>Présents enregistrés</span><strong>{statistics.present}</strong></article>
          </div>
        ) : <p className="portal-empty">Les statistiques apparaîtront après connexion à Supabase.</p>}
      </section>
    </div>
  );
}
