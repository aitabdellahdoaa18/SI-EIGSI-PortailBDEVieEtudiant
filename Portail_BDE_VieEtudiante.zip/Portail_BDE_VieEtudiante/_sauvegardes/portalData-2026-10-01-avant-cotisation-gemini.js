import { supabase } from './supabaseClient.js';

function requireSupabase() {
  if (!supabase) {
    throw new Error('La connexion Supabase n’est pas configurée.');
  }
  return supabase;
}

async function unwrap(query) {
  const { data, error } = await query;
  if (error) throw error;
  return data;
}

export async function getUserProfile(authUserId) {
  return unwrap(
    requireSupabase()
      .from('utilisateur')
      .select('id_utilisateur, nom, prenom, email, role')
      .eq('auth_user_id', authUserId)
      .single(),
  );
}

export async function getPublicEvents() {
  return unwrap(
    requireSupabase()
      .from('evenement')
      .select('id_evenement, titre, description, lieu, date_debut, date_fin, capacite_max')
      .eq('statut_publication', 'publie')
      .order('date_debut', { ascending: true }),
  );
}

export async function registerForEvent(eventId) {
  return unwrap(
    requireSupabase().rpc('inscrire_evenement', { p_id_evenement: eventId }),
  );
}

export async function getBdeEvents(userId) {
  return unwrap(
    requireSupabase()
      .from('evenement')
      .select('id_evenement, titre, lieu, date_debut, capacite_max, statut_publication')
      .eq('id_createur', userId)
      .order('date_debut', { ascending: true }),
  );
}

export async function createEvent(event) {
  return unwrap(
    requireSupabase().rpc('creer_evenement', {
      p_titre: event.titre,
      p_description: event.description,
      p_lieu: event.lieu,
      p_date_debut: event.date_debut,
      p_date_fin: event.date_fin || null,
      p_capacite_max: Number(event.capacite_max),
    }),
  );
}

export async function getEventRegistrations(eventId) {
  return unwrap(
    requireSupabase()
      .from('inscription')
      .select('id_inscription, date_inscription, statut_presence, utilisateur(id_utilisateur, nom, prenom, email)')
      .eq('id_evenement', eventId)
      .order('date_inscription', { ascending: true }),
  );
}

export async function setAttendance(registrationId, status) {
  return unwrap(
    requireSupabase().rpc('decider_presence', {
      p_id_inscription: registrationId,
      p_statut: status,
    }),
  );
}

export async function getPendingValidations() {
  return unwrap(
    requireSupabase()
      .from('validation')
      .select('id_validation, date_demande, commentaire, evenement(id_evenement, titre, lieu, date_debut, capacite_max)')
      .eq('statut', 'en_attente')
      .order('date_demande', { ascending: true }),
  );
}

export async function decideValidation(validationId, decision, comment = '') {
  return unwrap(
    requireSupabase().rpc('decider_validation', {
      p_id_validation: validationId,
      p_decision: decision,
      p_commentaire: comment,
    }),
  );
}

export async function getAdminStatistics() {
  const client = requireSupabase();
  const [events, registrations, present] = await Promise.all([
    client.from('evenement').select('id_evenement', { count: 'exact', head: true }),
    client.from('inscription').select('id_inscription', { count: 'exact', head: true }),
    client
      .from('inscription')
      .select('id_inscription', { count: 'exact', head: true })
      .eq('statut_presence', 'present'),
  ]);

  const firstError = events.error || registrations.error || present.error;
  if (firstError) throw firstError;

  return {
    events: events.count ?? 0,
    registrations: registrations.count ?? 0,
    present: present.count ?? 0,
  };
}
