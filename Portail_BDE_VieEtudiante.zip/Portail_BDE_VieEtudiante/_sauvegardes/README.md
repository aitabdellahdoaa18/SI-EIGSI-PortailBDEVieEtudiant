# Portail BDE — Vie étudiante

Première base de l’interface React/Vite du Portail BDE. La page initiale affiche « Hello » ; la connexion à Supabase sera activée après configuration du projet hébergé.

## Prérequis

- Node.js (version LTS)
- npm, fourni avec Node.js

## Installer et lancer sur Windows

Dans un terminal ouvert à la racine du projet :

```powershell
npm.cmd install
npm.cmd run dev
```

Vite affichera une adresse locale dans le terminal, généralement <http://localhost:5173/>. Ouvre cette adresse dans ton navigateur.

Pour vérifier qu’une version de production peut être construite :

```powershell
npm.cmd run build
```

Pour prévisualiser cette version construite :

```powershell
npm.cmd run preview
```

> Sur cette installation de Windows, `npm` est bloqué par la règle d’exécution PowerShell. Utilise `npm.cmd` comme dans les commandes ci-dessus ; il n’est pas nécessaire de modifier cette règle.

## Connexion à Supabase (facultative pour la page Hello)

1. Crée ou ouvre ton projet Supabase hébergé.
2. Copie `.env.example` vers `.env.local`.
3. Renseigne `VITE_SUPABASE_URL` et `VITE_SUPABASE_ANON_KEY` avec les valeurs publiques de ton projet.
4. Redémarre le serveur Vite.

Ne mets jamais une clé secrète `service_role` dans les variables de l’interface : elles sont visibles dans le navigateur. La base et les règles d’accès devront être définies avant d’ajouter des données réelles.

## Structure de départ

- `src/` — interface React.
- `src/pages/` — pages de l’application ; `Hello.jsx` est la page de test.
- `src/components/` — composants réutilisables.
- `src/lib/` — connexion Supabase et fonctions partagées.
- `supabase/migrations/` — emplacement futur des scripts SQL de migration.
