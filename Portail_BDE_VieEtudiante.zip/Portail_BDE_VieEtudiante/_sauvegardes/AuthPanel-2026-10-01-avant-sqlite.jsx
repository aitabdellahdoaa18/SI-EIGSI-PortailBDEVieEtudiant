import { useState } from 'react';
import { supabase } from '../lib/supabaseClient.js';

export default function AuthPanel({ onClose }) {
  const [mode, setMode] = useState('connexion');
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  async function handleSubmit(event) {
    event.preventDefault();
    setMessage('');
    setError('');

    if (!supabase) {
      setError('La connexion Supabase n’est pas configurée.');
      return;
    }

    const form = new FormData(event.currentTarget);
    const email = String(form.get('email')).trim();
    const password = String(form.get('password'));
    setBusy(true);

    try {
      if (mode === 'inscription') {
        const { data, error: authError } = await supabase.auth.signUp({
          email,
          password,
          options: {
            data: {
              nom: String(form.get('nom')).trim(),
              prenom: String(form.get('prenom')).trim(),
            },
          },
        });
        if (authError) throw authError;
        setMessage(data.session
          ? 'Compte créé. Tu es connecté comme étudiant.'
          : 'Compte créé. Consulte le courriel de Supabase pour confirmer ton adresse, puis connecte-toi.');
      } else {
        const { error: authError } = await supabase.auth.signInWithPassword({ email, password });
        if (authError) throw authError;
        setMessage('Connexion réussie.');
      }
    } catch {
      setError('Cette action a échoué. Vérifie les champs, la connexion Supabase et les réglages Auth.');
    } finally {
      setBusy(false);
    }
  }

  return (
    <section className="portal-panel auth-panel" aria-labelledby="auth-heading">
      <div className="portal-panel__heading">
        <div>
          <p className="portal-eyebrow">ESPACE ÉTUDIANT</p>
          <h2 id="auth-heading">{mode === 'connexion' ? 'Se connecter' : 'Créer un compte étudiant'}</h2>
        </div>
        {onClose && <button className="button button--quiet" type="button" onClick={onClose}>Fermer</button>}
      </div>

      <form className="portal-form" onSubmit={handleSubmit}>
        {mode === 'inscription' && (
          <div className="portal-form__row">
            <label>Prénom<input name="prenom" autoComplete="given-name" required /></label>
            <label>Nom<input name="nom" autoComplete="family-name" required /></label>
          </div>
        )}
        <label>Adresse e-mail<input name="email" type="email" autoComplete="email" required /></label>
        <label>Mot de passe<input name="password" type="password" autoComplete={mode === 'connexion' ? 'current-password' : 'new-password'} minLength="8" required /></label>
        <button className="button button--primary" type="submit" disabled={busy}>
          {busy ? 'Patiente…' : mode === 'connexion' ? 'Se connecter' : 'Créer mon compte'}
        </button>
      </form>

      {message && <p className="portal-feedback" role="status">{message}</p>}
      {error && <p className="portal-feedback portal-feedback--error" role="alert">{error}</p>}
      <p className="auth-switch">
        {mode === 'connexion' ? 'Pas encore de compte ?' : 'Tu as déjà un compte ?'}{' '}
        <button className="text-button" type="button" onClick={() => { setMode(mode === 'connexion' ? 'inscription' : 'connexion'); setMessage(''); setError(''); }}>
          {mode === 'connexion' ? 'Créer un compte étudiant' : 'Se connecter'}
        </button>
      </p>
    </section>
  );
}
