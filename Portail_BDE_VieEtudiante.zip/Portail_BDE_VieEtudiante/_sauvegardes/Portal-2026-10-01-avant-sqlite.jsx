import { useEffect, useState } from 'react';
import AuthPanel from '../components/AuthPanel.jsx';
import ClubMembership from '../components/ClubMembership.jsx';
import { getUserProfile } from '../lib/portalData.js';
import { supabase } from '../lib/supabaseClient.js';
import AdminDashboard from './AdminDashboard.jsx';
import BdeDashboard from './BdeDashboard.jsx';
import Events from './Events.jsx';
import './Portal.css';

const roleLabels = {
  etudiant: 'Espace étudiant',
  bde: 'Espace BDE',
  administration: 'Espace administration',
};

export default function Portal() {
  const [session, setSession] = useState(null);
  const [profile, setProfile] = useState(null);
  const [profileError, setProfileError] = useState('');
  const [activeView, setActiveView] = useState('evenements');
  const [loading, setLoading] = useState(Boolean(supabase));

  useEffect(() => {
    if (!supabase) return undefined;

    let mounted = true;
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, nextSession) => {
      if (mounted) {
        setSession(nextSession);
        setProfile(null);
        setProfileError('');
        setLoading(false);
      }
    });

    supabase.auth.getSession().then(({ data, error }) => {
      if (!mounted) return;
      if (error) setProfileError('Impossible de vérifier la session.');
      setSession(data.session);
      setLoading(false);
    });

    return () => {
      mounted = false;
      subscription.unsubscribe();
    };
  }, []);

  useEffect(() => {
    if (!supabase || !session?.user?.id) {
      setProfile(null);
      return undefined;
    }

    let mounted = true;
    getUserProfile(session.user.id)
      .then((userProfile) => { if (mounted) setProfile(userProfile); })
      .catch(() => { if (mounted) setProfileError('Le profil est introuvable. Vérifie la migration de création automatique des profils.'); });

    return () => { mounted = false; };
  }, [session]);

  async function handleSignOut() {
    if (!supabase) return;
    await supabase.auth.signOut();
    setProfile(null);
    setProfileError('');
    setActiveView('evenements');
  }

  if (loading) {
    return <main className="portal-shell"><p className="events-message">Vérification de la session…</p></main>;
  }

  const role = profile?.role;
  const availableViews = role === 'bde'
    ? [['evenements', 'Événements'], ['gestion-bde', 'Gestion BDE']]
    : role === 'administration'
      ? [['evenements', 'Événements'], ['administration', 'Demandes et statistiques']]
      : [['evenements', 'Événements'], ['clubs', 'Adhésions clubs']];

  return (
    <main className="portal-shell">
      <header className="portal-topbar">
        <a className="portal-brand" href="#evenements" onClick={() => setActiveView('evenements')}>EIGSI · PORTAIL BDE</a>
        {profile ? (
          <div className="portal-topbar__account">
            <span className="portal-user">{profile.prenom} {profile.nom} · {roleLabels[role]}</span>
            <button className="button button--quiet button--small" type="button" onClick={handleSignOut}>Déconnexion</button>
          </div>
        ) : <span className="portal-user">Bienvenue</span>}
      </header>

      {profile && (
        <nav className="portal-tabs" aria-label="Navigation principale">
          {availableViews.map(([view, label]) => (
            <button
              className="portal-tab"
              type="button"
              aria-current={activeView === view ? 'page' : undefined}
              key={view}
              onClick={() => setActiveView(view)}
            >
              {label}
            </button>
          ))}
        </nav>
      )}

      {profileError && <p className="portal-feedback portal-feedback--error" role="alert">{profileError}</p>}

      {activeView === 'evenements' && <Events profile={profile} />}
      {activeView === 'clubs' && role === 'etudiant' && <ClubMembership />}
      {activeView === 'gestion-bde' && role === 'bde' && <BdeDashboard profile={profile} />}
      {activeView === 'administration' && role === 'administration' && <AdminDashboard />}

      {!profile && supabase && <AuthPanel />}
      {!profile && !supabase && (
        <section className="portal-panel">
          <p className="portal-eyebrow">CONNEXION À CONFIGURER</p>
          <h2>Active le projet Supabase pour te connecter</h2>
          <p className="portal-empty">Renseigne l’URL et la clé publique du projet dans le fichier local <strong>.env.local</strong>, puis relance Vite. Les clés secrètes ne doivent jamais être mises ici.</p>
        </section>
      )}
    </main>
  );
}
