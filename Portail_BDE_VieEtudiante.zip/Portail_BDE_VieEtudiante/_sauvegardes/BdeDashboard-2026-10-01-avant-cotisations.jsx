import { useCallback, useEffect, useState } from 'react';
import { supabase } from '../lib/supabaseClient.js';
import {
  createEvent,
  getBdeEvents,
  getEventRegistrations,
  setAttendance,
} from '../lib/portalData.js';
import './Portal.css';

const dateFormatter = new Intl.DateTimeFormat('fr-FR', {
  dateStyle: 'medium',
  timeStyle: 'short',
  timeZone: 'Europe/Paris',
});

const statusLabels = {
  brouillon: 'Brouillon',
  en_attente_validation: 'En attente de validation',
  publie: 'Publié',
  refuse: 'Refusé',
  annule: 'Annulé',
};

export default function BdeDashboard({ profile }) {
  const [events, setEvents] = useState([]);
  const [selectedEventId, setSelectedEventId] = useState('');
  const [registrations, setRegistrations] = useState([]);
  const [feedback, setFeedback] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  const loadEvents = useCallback(async () => {
    try {
      const rows = await getBdeEvents(profile.id_utilisateur);
      setEvents(rows);
      setSelectedEventId((current) => current || String(rows[0]?.id_evenement ?? ''));
    } catch {
      setError('Impossible de charger tes événements. Vérifie la migration Supabase et ton rôle BDE.');
    }
  }, [profile.id_utilisateur]);

  const loadRegistrations = useCallback(async (eventId) => {
    if (!eventId) {
      setRegistrations([]);
      return;
    }
    try {
      setRegistrations(await getEventRegistrations(eventId));
      setError('');
    } catch {
      setError('Impossible de charger les inscriptions de cet événement.');
    }
  }, []);

  useEffect(() => { loadEvents(); }, [loadEvents]);
  useEffect(() => { loadRegistrations(selectedEventId); }, [loadRegistrations, selectedEventId]);

  useEffect(() => {
    if (!supabase || !selectedEventId) return undefined;
    const channel = supabase
      .channel(`inscriptions-evenement-${selectedEventId}`)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'inscription' }, () => {
        loadRegistrations(selectedEventId);
      })
      .subscribe();

    return () => { supabase.removeChannel(channel); };
  }, [loadRegistrations, selectedEventId]);

  async function handleCreateEvent(event) {
    event.preventDefault();
    const form = event.currentTarget;
    setFeedback('');
    setError('');
    setBusy(true);
    const formData = new FormData(form);

    try {
      await createEvent({
        titre: String(formData.get('titre')).trim(),
        description: String(formData.get('description')).trim(),
        lieu: String(formData.get('lieu')).trim(),
        date_debut: new Date(String(formData.get('date_debut'))).toISOString(),
        date_fin: formData.get('date_fin') ? new Date(String(formData.get('date_fin'))).toISOString() : null,
        capacite_max: formData.get('capacite_max'),
      });
      form.reset();
      setFeedback('Événement enregistré. Si son début est à 18 h ou après, il apparaît dans les demandes d’approbation ; sinon, il est publié directement.');
      await loadEvents();
    } catch {
      setError('Création impossible. Vérifie les informations, ta session et la migration Supabase.');
    } finally {
      setBusy(false);
    }
  }

  async function handleAttendance(registrationId, status) {
    setError('');
    try {
      await setAttendance(registrationId, status);
      await loadRegistrations(selectedEventId);
    } catch {
      setError('La mise à jour de présence a échoué.');
    }
  }

  const selectedEvent = events.find((event) => String(event.id_evenement) === String(selectedEventId));

  return (
    <div className="portal-columns">
      <section className="portal-panel">
        <div className="portal-panel__heading">
          <div><p className="portal-eyebrow">ESPACE BDE</p><h2>Créer un événement</h2></div>
        </div>
        <form className="portal-form" onSubmit={handleCreateEvent}>
          <label>Titre<input name="titre" required maxLength="140" /></label>
          <label>Description<textarea name="description" /></label>
          <div className="portal-form__row">
            <label>Début<input name="date_debut" type="datetime-local" required /></label>
            <label>Fin (facultatif)<input name="date_fin" type="datetime-local" /></label>
          </div>
          <div className="portal-form__row">
            <label>Lieu<input name="lieu" required /></label>
            <label>Places maximum<input name="capacite_max" type="number" min="1" step="1" required /></label>
          </div>
          <button className="button button--primary" disabled={busy} type="submit">
            {busy ? 'Enregistrement…' : 'Créer / soumettre'}
          </button>
        </form>
        {feedback && <p className="portal-feedback" role="status">{feedback}</p>}
        {error && <p className="portal-feedback portal-feedback--error" role="alert">{error}</p>}
      </section>

      <div>
        <section className="portal-panel">
          <div className="portal-panel__heading">
            <div><p className="portal-eyebrow">MES ÉVÉNEMENTS</p><h2>Suivre les inscriptions</h2></div>
            <button className="button button--quiet" type="button" onClick={() => loadRegistrations(selectedEventId)}>Actualiser</button>
          </div>
          {events.length === 0 ? (
            <p className="portal-empty">Tu n’as pas encore créé d’événement.</p>
          ) : (
            <>
              <label className="portal-form">Choisir un événement
                <select className="portal-select" value={selectedEventId} onChange={(event) => setSelectedEventId(event.target.value)}>
                  {events.map((item) => <option key={item.id_evenement} value={item.id_evenement}>{item.titre} — {statusLabels[item.statut_publication] ?? item.statut_publication}</option>)}
                </select>
              </label>
              {selectedEvent && <p className="portal-empty">{dateFormatter.format(new Date(selectedEvent.date_debut))} · {registrations.length} / {selectedEvent.capacite_max} inscrits</p>}
              <div className="portal-list">
                {registrations.map((registration) => (
                  <div className="portal-row" key={registration.id_inscription}>
                    <div>
                      <strong>{registration.utilisateur?.prenom} {registration.utilisateur?.nom}</strong>
                      <p>{registration.utilisateur?.email}</p>
                      <span className={`portal-status ${registration.statut_presence === 'present' ? 'portal-status--good' : registration.statut_presence === 'a_confirmer' ? 'portal-status--pending' : ''}`}>
                        {registration.statut_presence === 'present' ? 'Présent' : registration.statut_presence === 'absent' ? 'Absent' : 'Présence à confirmer'}
                      </span>
                    </div>
                    <div className="portal-row__actions">
                      <button className="button button--approve button--small" type="button" onClick={() => handleAttendance(registration.id_inscription, 'present')}>Présent</button>
                      <button className="button button--quiet button--small" type="button" onClick={() => handleAttendance(registration.id_inscription, 'absent')}>Absent</button>
                    </div>
                  </div>
                ))}
                {registrations.length === 0 && <p className="portal-empty">Aucune inscription pour cet événement.</p>}
              </div>
            </>
          )}
        </section>
      </div>
    </div>
  );
}
