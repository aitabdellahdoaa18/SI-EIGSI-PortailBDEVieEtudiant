import Events from './pages/Events.jsx';

export default function App() {
  return <Events />;
}
