import { useEffect, useState } from 'react';
import { registerForEvent } from '../lib/portalData.js';
import { supabase } from '../lib/supabaseClient.js';
import './Events.css';

const dateFormatter = new Intl.DateTimeFormat('fr-FR', {
  dateStyle: 'full',
  timeStyle: 'short',
  timeZone: 'Europe/Paris',
});

export default function Events({ profile }) {
  const [events, setEvents] = useState([]);
  const [loading, setLoading] = useState(Boolean(supabase));
  const [error, setError] = useState('');
  const [feedback, setFeedback] = useState('');
  const [registering, setRegistering] = useState(null);

  async function handleRegister(eventId) {
    setFeedback('');
    setError('');
    setRegistering(eventId);
    try {
      await registerForEvent(eventId);
      setFeedback('Inscription enregistrée. Tu es bien inscrit à cet événement.');
    } catch (registrationError) {
      setError(registrationError.message?.includes('capacité')
        ? 'Cet événement a atteint sa capacité maximale.'
        : registrationError.message?.includes('déjà inscrit')
          ? 'Tu es déjà inscrit à cet événement.'
          : 'L’inscription a échoué. Vérifie ton accès et réessaie.');
    } finally {
      setRegistering(null);
    }
  }

  useEffect(() => {
    if (!supabase) return;

    let stillMounted = true;

    async function loadEvents() {
      const { data, error: queryError } = await supabase
        .from('evenement')
        .select('id_evenement, titre, description, lieu, date_debut, date_fin, capacite_max')
        .eq('statut_publication', 'publie')
        .order('date_debut', { ascending: true });

      if (!stillMounted) return;

      if (queryError) {
        setError('Impossible de charger les événements. Vérifie la configuration Supabase et les règles d’accès.');
      } else {
        setEvents(data ?? []);
      }

      setLoading(false);
    }

    loadEvents();

    return () => {
      stillMounted = false;
    };
  }, []);

  return (
    <main className="events-page">
      <header className="events-header">
        <div>
          <span className="events-eyebrow">EIGSI · VIE ÉTUDIANTE</span>
          <h1>Les prochains rendez-vous</h1>
          <p>Découvre les événements proposés par le BDE.</p>
        </div>
        <span className="events-mark" aria-hidden="true">BDE</span>
      </header>

      {!supabase && (
        <section className="events-message" role="status">
          La connexion à Supabase n’est pas configurée. Applique la migration et les données de test,
          puis renseigne les paramètres dans <strong>.env.local</strong> pour afficher les événements.
        </section>
      )}

      {loading && <p className="events-message" role="status">Chargement des événements…</p>}
      {error && <p className="events-message events-message--error" role="alert">{error}</p>}
      {feedback && <p className="events-message" role="status">{feedback}</p>}

      {supabase && !loading && !error && events.length === 0 && (
        <p className="events-message">Aucun événement publié pour le moment.</p>
      )}

      <section className="events-grid" aria-label="Événements publiés">
        {events.map((event) => (
          <article className="event-card" key={event.id_evenement}>
            <div className="event-card__date">
              {dateFormatter.format(new Date(event.date_debut))}
            </div>
            <h2>{event.titre}</h2>
            <p className="event-card__description">{event.description}</p>
            <div className="event-card__details">
              <span>{event.lieu}</span>
              <span>{event.capacite_max} places maximum</span>
            </div>
            {profile?.role === 'etudiant' && (
              <button
                className="button button--primary event-card__action"
                type="button"
                disabled={registering === event.id_evenement}
                onClick={() => handleRegister(event.id_evenement)}
              >
                {registering === event.id_evenement ? 'Inscription…' : 'S’inscrire'}
              </button>
            )}
          </article>
        ))}
      </section>
    </main>
  );
}
