-- Données de démonstration fictives pour un projet Supabase de test.
-- Les adresses utilisent le domaine réservé example.test et ne sont pas réelles.

begin;

insert into public.utilisateur (id_utilisateur, nom, prenom, email, role) values
  (900001, 'Martin', 'Emma', 'emma.martin@example.test', 'etudiant'),
  (900002, 'El Amrani', 'Sami', 'sami.elamrani@example.test', 'bde'),
  (900003, 'Laurent', 'Nadia', 'nadia.laurent@example.test', 'administration'),
  (900004, 'Bernard', 'Yanis', 'yanis.bernard@example.test', 'etudiant')
on conflict (id_utilisateur) do update set
  nom = excluded.nom,
  prenom = excluded.prenom,
  email = excluded.email,
  role = excluded.role;

insert into public.club (id_club, nom, description) values
  (900201, 'Club Photo', 'Ateliers photo et couverture des événements étudiants.'),
  (900202, 'Club Robotique', 'Projets de robotique et séances de découverte.')
on conflict (id_club) do update set
  nom = excluded.nom,
  description = excluded.description;

insert into public.evenement (
  id_evenement, id_createur, titre, description, lieu, date_debut, date_fin,
  capacite_max, statut_publication
) values
  (
    900101, 900002, 'Après-midi de rentrée',
    'Rencontre de rentrée organisée par le BDE pour découvrir les associations.',
    'Campus EIGSI — La Rochelle', '2026-10-14 15:00:00+02', '2026-10-14 17:00:00+02',
    80, 'publie'
  ),
  (
    900102, 900002, 'Soirée des clubs étudiants',
    'Présentation des clubs et échanges entre étudiants ; demande en attente de validation administrative.',
    'Campus EIGSI — La Rochelle', '2026-10-21 19:00:00+02', '2026-10-21 22:00:00+02',
    120, 'en_attente_validation'
  ),
  (
    900103, 900002, 'Atelier découverte photo',
    'Initiation à la photographie proposée par le Club Photo.',
    'Salle associative — Campus EIGSI', '2026-10-28 16:00:00+02', '2026-10-28 18:00:00+02',
    20, 'publie'
  )
on conflict (id_evenement) do update set
  id_createur = excluded.id_createur,
  titre = excluded.titre,
  description = excluded.description,
  lieu = excluded.lieu,
  date_debut = excluded.date_debut,
  date_fin = excluded.date_fin,
  capacite_max = excluded.capacite_max,
  statut_publication = excluded.statut_publication;

insert into public.inscription (
  id_inscription, id_utilisateur, id_evenement, date_inscription, statut_presence
) values
  (900301, 900001, 900101, '2026-10-02 10:15:00+02', 'a_confirmer'),
  (900302, 900004, 900101, '2026-10-02 11:40:00+02', 'a_confirmer'),
  (900303, 900001, 900103, '2026-10-03 09:05:00+02', 'a_confirmer')
on conflict (id_inscription) do update set
  id_utilisateur = excluded.id_utilisateur,
  id_evenement = excluded.id_evenement,
  date_inscription = excluded.date_inscription,
  statut_presence = excluded.statut_presence;

insert into public.adhesion (
  id_adhesion, id_utilisateur, id_club, date_adhesion, statut,
  plan_cotisation, cycle_etude, annee_academique, montant_mad,
  date_confirmation_paiement, id_confirme_par
) values
  (900401, 900001, 900201, '2026-09-15', 'active', 'annuelle', null, '2026-2027', 200, '2026-09-16 12:00:00+02', 900003),
  (900402, 900004, 900202, '2026-09-18', 'active', 'annuelle', null, '2026-2027', 200, '2026-09-19 12:00:00+02', 900003),
  (900403, 900004, 900201, '2026-09-20', 'en_attente_paiement', 'cycle', 'prepa', null, 300, null, null)
on conflict (id_adhesion) do update set
  id_utilisateur = excluded.id_utilisateur,
  id_club = excluded.id_club,
  date_adhesion = excluded.date_adhesion,
  statut = excluded.statut,
  plan_cotisation = excluded.plan_cotisation,
  cycle_etude = excluded.cycle_etude,
  annee_academique = excluded.annee_academique,
  montant_mad = excluded.montant_mad,
  date_confirmation_paiement = excluded.date_confirmation_paiement,
  id_confirme_par = excluded.id_confirme_par;

insert into public.validation (
  id_validation, id_evenement, id_admin, statut, date_demande, date_decision, commentaire
) values
  (
    900501, 900102, null, 'en_attente', '2026-10-01 12:00:00+02', null,
    'Événement après 18 h : en attente d’examen.'
  )
on conflict (id_validation) do update set
  id_evenement = excluded.id_evenement,
  id_admin = excluded.id_admin,
  statut = excluded.statut,
  date_demande = excluded.date_demande,
  date_decision = excluded.date_decision,
  commentaire = excluded.commentaire;

-- La table affiche_ia reste vide jusqu'à l'ajout réel de la génération d'affiches.

-- Recaler les séquences après l'emploi d'identifiants de démonstration explicites.
select setval(pg_get_serial_sequence('public.utilisateur', 'id_utilisateur'), (select max(id_utilisateur) from public.utilisateur), true);
select setval(pg_get_serial_sequence('public.club', 'id_club'), (select max(id_club) from public.club), true);
select setval(pg_get_serial_sequence('public.evenement', 'id_evenement'), (select max(id_evenement) from public.evenement), true);
select setval(pg_get_serial_sequence('public.inscription', 'id_inscription'), (select max(id_inscription) from public.inscription), true);
select setval(pg_get_serial_sequence('public.adhesion', 'id_adhesion'), (select max(id_adhesion) from public.adhesion), true);
select setval(pg_get_serial_sequence('public.validation', 'id_validation'), (select max(id_validation) from public.validation), true);

commit;
