import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};

function jsonResponse(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, 'Content-Type': 'application/json' },
  });
}

Deno.serve(async (request: Request) => {
  if (request.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  if (request.method !== 'POST') return jsonResponse({ error: 'Méthode non autorisée.' }, 405);

  const authorization = request.headers.get('Authorization');
  const supabaseUrl = Deno.env.get('SUPABASE_URL');
  const anonKey = Deno.env.get('SUPABASE_ANON_KEY');
  const geminiApiKey = Deno.env.get('GEMINI_API_KEY');
  const geminiModel = Deno.env.get('GEMINI_IMAGE_MODEL') ?? 'gemini-2.5-flash-image';

  if (!authorization || !supabaseUrl || !anonKey) {
    return jsonResponse({ error: 'Session ou configuration Supabase manquante.' }, 401);
  }
  if (!geminiApiKey) {
    return jsonResponse({ error: 'La clé Google Gemini doit être configurée comme secret de la fonction Supabase.' }, 503);
  }

  const client = createClient(supabaseUrl, anonKey, {
    global: { headers: { Authorization: authorization } },
    auth: { persistSession: false, autoRefreshToken: false },
  });
  const { data: { user }, error: userError } = await client.auth.getUser();
  if (userError || !user) return jsonResponse({ error: 'Session invalide.' }, 401);

  const { data: profile, error: profileError } = await client
    .from('utilisateur')
    .select('id_utilisateur, role')
    .eq('auth_user_id', user.id)
    .single();
  if (profileError || profile?.role !== 'bde') {
    return jsonResponse({ error: 'La génération d’affiche est réservée au BDE.' }, 403);
  }

  let body: { eventId?: number; prompt?: string };
  try {
    body = await request.json();
  } catch {
    return jsonResponse({ error: 'Requête JSON invalide.' }, 400);
  }
  const eventId = Number(body.eventId);
  const prompt = String(body.prompt ?? '').trim();
  if (!Number.isSafeInteger(eventId) || eventId < 1 || prompt.length < 10 || prompt.length > 1500) {
    return jsonResponse({ error: 'Événement ou description invalide (10 à 1500 caractères).' }, 400);
  }

  const { data: event, error: eventError } = await client
    .from('evenement')
    .select('id_evenement, titre, description, date_debut, lieu, id_createur')
    .eq('id_evenement', eventId)
    .single();
  if (eventError || event.id_createur !== profile.id_utilisateur) {
    return jsonResponse({ error: 'Événement introuvable ou accès refusé.' }, 403);
  }

  const imagePrompt = [
    'Create a polished, student-friendly event poster illustration for a French engineering school in La Rochelle.',
    'Do not include written text, logos, or fake lettering; the website overlays event details separately.',
    `Event: ${event.titre}. Place: ${event.lieu}. Description: ${event.description}.`,
    `BDE direction: ${prompt}`,
  ].join('\n');

  const generationResponse = await fetch(
    `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(geminiModel)}:generateContent`,
    {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-goog-api-key': geminiApiKey,
      },
      body: JSON.stringify({
        contents: [{ role: 'user', parts: [{ text: imagePrompt }] }],
        generationConfig: { responseModalities: ['TEXT', 'IMAGE'] },
      }),
    },
  );
  if (!generationResponse.ok) {
    console.error('Gemini generation failed:', generationResponse.status, await generationResponse.text());
    return jsonResponse({ error: 'Google Gemini n’a pas pu générer l’image. Vérifie le modèle et les droits de la clé.' }, 502);
  }

  const generated = await generationResponse.json();
  const parts = generated?.candidates?.[0]?.content?.parts ?? [];
  const imagePart = parts.find((part: { inlineData?: { data?: string; mimeType?: string } }) => part.inlineData?.data);
  const imageBase64 = imagePart?.inlineData?.data;
  const mimeType = imagePart?.inlineData?.mimeType ?? 'image/png';
  if (!imageBase64) {
    return jsonResponse({ error: 'Gemini n’a renvoyé aucune image. Vérifie la disponibilité du modèle de génération choisi.' }, 502);
  }

  const imageBytes = Uint8Array.from(atob(imageBase64), (character) => character.charCodeAt(0));
  const extension = mimeType === 'image/jpeg' ? 'jpg' : 'png';
  const objectPath = `${event.id_evenement}/${crypto.randomUUID()}.${extension}`;
  const { error: uploadError } = await client.storage
    .from('affiches')
    .upload(objectPath, imageBytes, { contentType: mimeType, upsert: false });
  if (uploadError) {
    console.error('Poster upload failed:', uploadError.message);
    return jsonResponse({ error: 'Image générée mais impossible de l’enregistrer dans le stockage Supabase.' }, 500);
  }

  const { data: posterId, error: recordError } = await client.rpc('enregistrer_affiche_ia', {
    p_id_evenement: event.id_evenement,
    p_url_image: objectPath,
    p_prompt: prompt,
  });
  if (recordError) {
    await client.storage.from('affiches').remove([objectPath]);
    console.error('Poster record failed:', recordError.message);
    return jsonResponse({ error: 'Image produite mais impossible de l’enregistrer dans le catalogue.' }, 500);
  }

  return jsonResponse({ posterId, objectPath, status: 'a_verifier' });
});
