-- Cotisations hors portail : le portail enregistre la formule et attend
-- la confirmation manuelle du BDE après réception du paiement externe.

alter table public.adhesion
  drop constraint if exists adhesion_id_utilisateur_id_club_key;

alter table public.adhesion
  add column plan_cotisation text not null default 'annuelle',
  add column cycle_etude text,
  add column annee_academique text,
  add column montant_mad numeric(7, 2) not null default 200,
  add column date_confirmation_paiement timestamptz,
  add column id_confirme_par bigint references public.utilisateur (id_utilisateur) on delete set null;

update public.adhesion
set annee_academique = case
  when extract(month from date_adhesion) >= 9 then
    extract(year from date_adhesion)::integer::text || '-' || (extract(year from date_adhesion)::integer + 1)::text
  else
    (extract(year from date_adhesion)::integer - 1)::text || '-' || extract(year from date_adhesion)::integer::text
end
where annee_academique is null;

-- Conserver comme paiements confirmés les adhésions actives déjà présentes
-- avant l’ajout des colonnes de suivi de règlement.
update public.adhesion
set date_confirmation_paiement = date_adhesion::timestamptz
where statut = 'active'
  and date_confirmation_paiement is null;

alter table public.adhesion
  drop constraint if exists adhesion_statut_check;

alter table public.adhesion
  add constraint adhesion_statut_check
    check (statut in ('en_attente', 'en_attente_paiement', 'active', 'refusee', 'terminee')),
  add constraint adhesion_formule_check
    check (
      (plan_cotisation = 'annuelle' and cycle_etude is null and annee_academique is not null and montant_mad = 200)
      or
      (plan_cotisation = 'cycle' and cycle_etude in ('prepa', 'ingenieur') and annee_academique is null and montant_mad = 300)
    ),
  add constraint adhesion_confirmation_check
    check ((statut = 'active' and date_confirmation_paiement is not null) or statut <> 'active');

create unique index adhesion_annuelle_unique
  on public.adhesion (id_utilisateur, id_club, annee_academique)
  where plan_cotisation = 'annuelle';
create unique index adhesion_cycle_unique
  on public.adhesion (id_utilisateur, id_club, cycle_etude)
  where plan_cotisation = 'cycle';

-- Une demande choisit 200 MAD pour l'année scolaire ou 300 MAD pour le cycle
-- Prépa / Ingénieur. Le règlement se fait hors du portail.
create or replace function public.demander_adhesion(
  p_id_club bigint,
  p_plan text,
  p_cycle_etude text default null
)
returns bigint
language plpgsql
security definer
set search_path = public, auth
as $$
declare
  v_utilisateur bigint;
  v_adhesion bigint;
  v_annee text;
  v_montant numeric(7, 2);
begin
  if public.current_portal_user_role() is distinct from 'etudiant' then
    raise exception 'Seul un compte étudiant peut demander une adhésion.';
  end if;
  if not exists (select 1 from public.club where id_club = p_id_club) then
    raise exception 'Club introuvable.';
  end if;

  if p_plan = 'annuelle' and p_cycle_etude is null then
    v_montant := 200;
    v_annee := case
      when extract(month from (now() at time zone 'Africa/Casablanca')) >= 9 then
        extract(year from (now() at time zone 'Africa/Casablanca'))::integer::text || '-' ||
        (extract(year from (now() at time zone 'Africa/Casablanca'))::integer + 1)::text
      else
        (extract(year from (now() at time zone 'Africa/Casablanca'))::integer - 1)::text || '-' ||
        extract(year from (now() at time zone 'Africa/Casablanca'))::integer::text
    end;
  elsif p_plan = 'cycle' and p_cycle_etude in ('prepa', 'ingenieur') then
    v_montant := 300;
    v_annee := null;
  else
    raise exception 'Choisis 200 MAD à l’année ou 300 MAD pour le cycle Prépa ou Ingénieur.';
  end if;

  v_utilisateur := public.current_portal_user_id();
  insert into public.adhesion (
    id_utilisateur, id_club, date_adhesion, statut,
    plan_cotisation, cycle_etude, annee_academique, montant_mad
  ) values (
    v_utilisateur, p_id_club, current_date, 'en_attente_paiement',
    p_plan, p_cycle_etude, v_annee, v_montant
  ) returning id_adhesion into v_adhesion;

  return v_adhesion;
exception
  when unique_violation then
    raise exception 'Une cotisation pour cette formule existe déjà pour ce club.';
end;
$$;

create or replace function public.confirmer_cotisation(p_id_adhesion bigint)
returns void
language plpgsql
security definer
set search_path = public, auth
as $$
begin
  if coalesce(public.current_portal_user_role(), '') not in ('bde', 'administration') then
    raise exception 'Seul le BDE ou l’administration peut confirmer un règlement reçu hors du portail.';
  end if;

  update public.adhesion
  set statut = 'active',
      date_confirmation_paiement = now(),
      id_confirme_par = public.current_portal_user_id()
  where id_adhesion = p_id_adhesion
    and statut = 'en_attente_paiement';

  if not found then
    raise exception 'Demande introuvable ou déjà confirmée.';
  end if;
end;
$$;

create or replace function public.enregistrer_affiche_ia(
  p_id_evenement bigint,
  p_url_image text,
  p_prompt text
)
returns bigint
language plpgsql
security definer
set search_path = public, auth
as $$
declare
  v_affiche bigint;
begin
  if public.current_portal_user_role() is distinct from 'bde' then
    raise exception 'Seul un compte BDE peut enregistrer une affiche.';
  end if;
  if not exists (
    select 1 from public.evenement e
    where e.id_evenement = p_id_evenement
      and e.id_createur = public.current_portal_user_id()
  ) then
    raise exception 'Événement introuvable ou accès refusé.';
  end if;
  if p_url_image is null or btrim(p_url_image) = '' or p_prompt is null then
    raise exception 'Image et description de la demande requises.';
  end if;

  insert into public.affiche_ia (id_evenement, url_image, id_generateur, prompt)
  values (p_id_evenement, p_url_image, public.current_portal_user_id(), p_prompt)
  returning id_affiche into v_affiche;

  return v_affiche;
end;
$$;

revoke all on function public.demander_adhesion(bigint, text, text) from public;
revoke all on function public.confirmer_cotisation(bigint) from public;
revoke all on function public.enregistrer_affiche_ia(bigint, text, text) from public;
grant execute on function public.demander_adhesion(bigint, text, text) to authenticated;
grant execute on function public.confirmer_cotisation(bigint) to authenticated;
grant execute on function public.enregistrer_affiche_ia(bigint, text, text) to authenticated;

drop policy if exists "Adhésions propres ou gérées" on public.adhesion;
create policy "Adhésions propres ou gérées"
  on public.adhesion
  for select
  to authenticated
  using (
    id_utilisateur = public.current_portal_user_id()
    or public.current_portal_user_role() in ('bde', 'administration')
  );

grant select on table public.adhesion to authenticated;

-- Le BDE doit voir le nom des étudiants dont il suit la cotisation.
drop policy if exists "BDE voit les membres" on public.utilisateur;
create policy "BDE voit les membres"
  on public.utilisateur
  for select
  to authenticated
  using (
    public.current_portal_user_role() in ('bde', 'administration')
    and exists (
      select 1
      from public.adhesion a
      where a.id_utilisateur = utilisateur.id_utilisateur
    )
  );

alter table public.affiche_ia
  add column id_generateur bigint references public.utilisateur (id_utilisateur) on delete set null,
  add column prompt text not null default '';

grant select on table public.affiche_ia to anon, authenticated;
drop policy if exists "Affiches publiques validees ou gerees" on public.affiche_ia;
create policy "Affiches publiques validees ou gerees"
  on public.affiche_ia
  for select
  to anon, authenticated
  using (
    statut_validation = 'validee'
    or (
      auth.role() = 'authenticated'
      and (
        public.current_portal_user_role() = 'administration'
        or exists (
          select 1 from public.evenement e
          where e.id_evenement = affiche_ia.id_evenement
            and e.id_createur = public.current_portal_user_id()
        )
      )
    )
  );

create or replace function public.decider_affiche_ia(p_id_affiche bigint, p_decision text)
returns void
language plpgsql
security definer
set search_path = public, auth
as $$
begin
  if public.current_portal_user_role() is distinct from 'bde' then
    raise exception 'Seul un membre autorisé du BDE peut valider une affiche.';
  end if;
  if p_decision is null or p_decision not in ('validee', 'refusee') then
    raise exception 'Choisis valider ou refuser.';
  end if;

  update public.affiche_ia ai
  set statut_validation = p_decision,
      id_validateur = public.current_portal_user_id()
  where ai.id_affiche = p_id_affiche
    and ai.statut_validation = 'a_verifier'
    and exists (
      select 1 from public.evenement e
      where e.id_evenement = ai.id_evenement
        and e.id_createur = public.current_portal_user_id()
    );

  if not found then
    raise exception 'Affiche introuvable ou accès refusé.';
  end if;
end;
$$;

revoke all on function public.decider_affiche_ia(bigint, text) from public;
grant execute on function public.decider_affiche_ia(bigint, text) to authenticated;

-- Les images restent privées jusqu'à la validation du BDE.
insert into storage.buckets (id, name, public)
values ('affiches', 'affiches', false)
on conflict (id) do update set public = false;

drop policy if exists "Lire affiches validees ou gerees" on storage.objects;
create policy "Lire affiches validees ou gerees"
  on storage.objects
  for select
  to anon, authenticated
  using (
    bucket_id = 'affiches'
    and exists (
      select 1
      from public.affiche_ia ai
      join public.evenement e on e.id_evenement = ai.id_evenement
      where ai.url_image = storage.objects.name
        and (
          ai.statut_validation = 'validee'
          or (
            auth.role() = 'authenticated'
            and (
              public.current_portal_user_role() = 'administration'
              or e.id_createur = public.current_portal_user_id()
            )
          )
        )
    )
  );

drop policy if exists "BDE peut déposer ses affiches" on storage.objects;
create policy "BDE peut déposer ses affiches"
  on storage.objects
  for insert
  to authenticated
  with check (
    bucket_id = 'affiches'
    and public.current_portal_user_role() = 'bde'
    and exists (
      select 1 from public.evenement e
      where e.id_evenement::text = split_part(storage.objects.name, '/', 1)
        and e.id_createur = public.current_portal_user_id()
    )
  );
