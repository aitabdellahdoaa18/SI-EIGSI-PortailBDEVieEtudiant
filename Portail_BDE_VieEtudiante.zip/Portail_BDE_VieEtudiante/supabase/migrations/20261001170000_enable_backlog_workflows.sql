-- Étape 2 du schéma : profils Supabase Auth, rôles et parcours événementiel.
-- Convention confirmée : une validation admin est exigée si l'heure locale de début
-- est supérieure ou égale à 18:00 (fuseau Europe/Paris).

alter table public.evenement
  alter column capacite_max set not null;

alter table public.evenement
  drop constraint if exists evenement_statut_publication_check;

alter table public.evenement
  add constraint evenement_statut_publication_check
  check (statut_publication in ('brouillon', 'en_attente_validation', 'publie', 'refuse', 'annule'));

create or replace function public.current_portal_user_id()
returns bigint
language sql
stable
security definer
set search_path = public
as $$
  select id_utilisateur
  from public.utilisateur
  where auth_user_id = auth.uid()
  limit 1;
$$;

create or replace function public.current_portal_user_role()
returns text
language sql
stable
security definer
set search_path = public
as $$
  select role
  from public.utilisateur
  where auth_user_id = auth.uid()
  limit 1;
$$;

revoke all on function public.current_portal_user_id() from public;
revoke all on function public.current_portal_user_role() from public;
grant execute on function public.current_portal_user_id() to authenticated;
grant execute on function public.current_portal_user_role() to authenticated;

-- Un compte créé via Supabase Auth devient étudiant par défaut.
-- Les rôles BDE/administration sont attribués manuellement par une personne admin,
-- jamais par des champs envoyés depuis le formulaire public d'inscription.
create or replace function public.create_portal_profile_for_auth_user()
returns trigger
language plpgsql
security definer
set search_path = public, auth
as $$
begin
  if new.email is null then
    raise exception 'Une adresse e-mail est nécessaire pour créer un profil portail.';
  end if;

  insert into public.utilisateur (auth_user_id, nom, prenom, email, role)
  values (
    new.id,
    coalesce(nullif(new.raw_user_meta_data ->> 'nom', ''), split_part(new.email, '@', 1)),
    coalesce(nullif(new.raw_user_meta_data ->> 'prenom', ''), ''),
    new.email,
    'etudiant'
  )
  on conflict (auth_user_id) do nothing;

  return new;
end;
$$;

revoke all on function public.create_portal_profile_for_auth_user() from public;
drop trigger if exists on_auth_user_created_portal_profile on auth.users;
create trigger on_auth_user_created_portal_profile
after insert on auth.users
for each row execute function public.create_portal_profile_for_auth_user();

-- Une personne ne peut lire que son propre profil. Le BDE voit les étudiants
-- inscrits aux événements qu'il a créés ; l'administration peut consulter les profils.
drop policy if exists "Profil propre ou rôle autorisé" on public.utilisateur;
create policy "Profil propre ou rôle autorisé"
  on public.utilisateur
  for select
  to authenticated
  using (
    auth_user_id = auth.uid()
    or public.current_portal_user_role() = 'administration'
    or (
      public.current_portal_user_role() = 'bde'
      and exists (
        select 1
        from public.inscription i
        join public.evenement e on e.id_evenement = i.id_evenement
        where i.id_utilisateur = utilisateur.id_utilisateur
          and e.id_createur = public.current_portal_user_id()
      )
    )
  );

drop policy if exists "Événements publics ou de gestion" on public.evenement;
create policy "Événements publics ou de gestion"
  on public.evenement
  for select
  to authenticated
  using (
    statut_publication = 'publie'
    or id_createur = public.current_portal_user_id()
    or public.current_portal_user_role() = 'administration'
  );

-- L'écran de validation expose aux administrateurs les demandes et au BDE
-- uniquement les demandes liées à ses événements.
grant select on table public.utilisateur, public.inscription, public.validation,
  public.club, public.adhesion to authenticated;

drop policy if exists "Voir les demandes liées à son rôle" on public.validation;
create policy "Voir les demandes liées à son rôle"
  on public.validation
  for select
  to authenticated
  using (
    public.current_portal_user_role() = 'administration'
    or exists (
      select 1
      from public.evenement e
      where e.id_evenement = validation.id_evenement
        and e.id_createur = public.current_portal_user_id()
    )
  );

drop policy if exists "Voir inscriptions propres ou de ses événements" on public.inscription;
create policy "Voir inscriptions propres ou de ses événements"
  on public.inscription
  for select
  to authenticated
  using (
    id_utilisateur = public.current_portal_user_id()
    or public.current_portal_user_role() = 'administration'
    or exists (
      select 1
      from public.evenement e
      where e.id_evenement = inscription.id_evenement
        and e.id_createur = public.current_portal_user_id()
    )
  );

drop policy if exists "Présence modifiable par gestionnaire" on public.inscription;
create policy "Présence modifiable par gestionnaire"
  on public.inscription
  for update
  to authenticated
  using (
    public.current_portal_user_role() = 'administration'
    or exists (
      select 1
      from public.evenement e
      where e.id_evenement = inscription.id_evenement
        and e.id_createur = public.current_portal_user_id()
    )
  )
  with check (
    public.current_portal_user_role() = 'administration'
    or exists (
      select 1
      from public.evenement e
      where e.id_evenement = inscription.id_evenement
        and e.id_createur = public.current_portal_user_id()
    )
  );

grant update (statut_presence) on table public.inscription to authenticated;

drop policy if exists "Clubs visibles" on public.club;
create policy "Clubs visibles" on public.club for select to anon, authenticated using (true);
grant select on table public.club to anon;
grant select on table public.evenement to authenticated;

-- Événement et demande éventuelle sont créés dans une seule transaction.
create or replace function public.creer_evenement(
  p_titre text,
  p_description text,
  p_lieu text,
  p_date_debut timestamptz,
  p_date_fin timestamptz,
  p_capacite_max integer
)
returns bigint
language plpgsql
security definer
set search_path = public, auth
as $$
declare
  v_createur bigint;
  v_evenement bigint;
  v_validation_requise boolean;
  v_heure_locale time;
begin
  if public.current_portal_user_role() is distinct from 'bde' then
    raise exception 'Seul un compte BDE peut créer un événement.';
  end if;
  if nullif(btrim(p_titre), '') is null or nullif(btrim(p_lieu), '') is null then
    raise exception 'Le titre et le lieu sont obligatoires.';
  end if;
  if p_date_debut is null or p_capacite_max is null or p_capacite_max < 1 then
    raise exception 'La date de début et une capacité positive sont obligatoires.';
  end if;
  if p_date_fin is not null and p_date_fin < p_date_debut then
    raise exception 'La date de fin ne peut pas précéder le début.';
  end if;

  v_createur := public.current_portal_user_id();
  v_heure_locale := timezone('Europe/Paris', p_date_debut)::time;
  v_validation_requise := v_heure_locale >= time '18:00';

  insert into public.evenement (
    id_createur, titre, description, lieu, date_debut, date_fin,
    capacite_max, statut_publication
  ) values (
    v_createur,
    btrim(p_titre),
    coalesce(p_description, ''),
    btrim(p_lieu),
    p_date_debut,
    p_date_fin,
    p_capacite_max,
    case when v_validation_requise then 'en_attente_validation' else 'publie' end
  ) returning id_evenement into v_evenement;

  if v_validation_requise then
    insert into public.validation (id_evenement, statut, commentaire)
    values (v_evenement, 'en_attente', 'En attente d’approbation administrative (début à 18 h ou après).');
  end if;

  return v_evenement;
end;
$$;

create or replace function public.decider_validation(
  p_id_validation bigint,
  p_decision text,
  p_commentaire text default ''
)
returns void
language plpgsql
security definer
set search_path = public, auth
as $$
declare
  v_evenement bigint;
begin
  if public.current_portal_user_role() is distinct from 'administration' then
    raise exception 'Seul un compte administration peut traiter une demande.';
  end if;
  if p_decision is null or p_decision not in ('valide', 'refuse') then
    raise exception 'La décision doit être valide ou refuse.';
  end if;

  update public.validation
  set statut = p_decision,
      id_admin = public.current_portal_user_id(),
      date_decision = now(),
      commentaire = coalesce(p_commentaire, '')
  where id_validation = p_id_validation
    and statut = 'en_attente'
  returning id_evenement into v_evenement;

  if v_evenement is null then
    raise exception 'Demande introuvable ou déjà traitée.';
  end if;

  update public.evenement
  set statut_publication = case when p_decision = 'valide' then 'publie' else 'refuse' end
  where id_evenement = v_evenement;
end;
$$;

create or replace function public.inscrire_evenement(p_id_evenement bigint)
returns bigint
language plpgsql
security definer
set search_path = public, auth
as $$
declare
  v_utilisateur bigint;
  v_capacite integer;
  v_places_prises bigint;
  v_inscription bigint;
begin
  if public.current_portal_user_role() is distinct from 'etudiant' then
    raise exception 'Seul un compte étudiant peut s’inscrire.';
  end if;

  v_utilisateur := public.current_portal_user_id();
  select capacite_max into v_capacite
  from public.evenement
  where id_evenement = p_id_evenement
    and statut_publication = 'publie'
  for update;

  if not found then
    raise exception 'Cet événement n’est pas ouvert aux inscriptions.';
  end if;

  select count(*) into v_places_prises
  from public.inscription
  where id_evenement = p_id_evenement;

  if v_places_prises >= v_capacite then
    raise exception 'Cet événement a atteint sa capacité maximale.';
  end if;

  insert into public.inscription (id_utilisateur, id_evenement)
  values (v_utilisateur, p_id_evenement)
  on conflict (id_utilisateur, id_evenement) do nothing
  returning id_inscription into v_inscription;

  if v_inscription is null then
    raise exception 'Tu es déjà inscrit à cet événement.';
  end if;

  return v_inscription;
end;
$$;

create or replace function public.decider_presence(
  p_id_inscription bigint,
  p_statut text
)
returns void
language plpgsql
security definer
set search_path = public, auth
as $$
begin
  if p_statut is null or p_statut not in ('present', 'absent', 'a_confirmer') then
    raise exception 'État de présence inconnu.';
  end if;
  if coalesce(public.current_portal_user_role(), '') not in ('bde', 'administration') then
    raise exception 'Seuls le BDE ou l’administration peuvent gérer les présences.';
  end if;

  update public.inscription i
  set statut_presence = p_statut
  where i.id_inscription = p_id_inscription
    and (
      public.current_portal_user_role() = 'administration'
      or exists (
        select 1 from public.evenement e
        where e.id_evenement = i.id_evenement
          and e.id_createur = public.current_portal_user_id()
      )
    );

  if not found then
    raise exception 'Inscription introuvable ou accès refusé.';
  end if;
end;
$$;

revoke all on function public.creer_evenement(text, text, text, timestamptz, timestamptz, integer) from public;
revoke all on function public.decider_validation(bigint, text, text) from public;
revoke all on function public.inscrire_evenement(bigint) from public;
revoke all on function public.decider_presence(bigint, text) from public;
grant execute on function public.creer_evenement(text, text, text, timestamptz, timestamptz, integer) to authenticated;
grant execute on function public.decider_validation(bigint, text, text) to authenticated;
grant execute on function public.inscrire_evenement(bigint) to authenticated;
grant execute on function public.decider_presence(bigint, text) to authenticated;

-- Active les mises à jour en temps réel des inscriptions si la publication Supabase existe.
do $$
begin
  if exists (select 1 from pg_publication where pubname = 'supabase_realtime')
     and not exists (
       select 1 from pg_publication_tables
       where pubname = 'supabase_realtime'
         and schemaname = 'public'
         and tablename = 'inscription'
     ) then
    alter publication supabase_realtime add table public.inscription;
  end if;
end;
$$;
