# Portail BDE — Vie étudiante

Première version de l’interface React/Vite du Portail BDE. La page d’accueil affiche les événements publiés depuis Supabase après l’application de la migration, du jeu de test et la configuration du projet hébergé.

## Prérequis

- Node.js (version LTS)
- npm, fourni avec Node.js

## Installer et lancer sur Windows

Dans un terminal ouvert à la racine du projet :

```powershell
npm.cmd install
npm.cmd run dev
```

Vite affichera une adresse locale dans le terminal, généralement <http://localhost:5173/>. Ouvre cette adresse dans ton navigateur.

Pour vérifier qu’une version de production peut être construite :

```powershell
npm.cmd run build
```

Pour prévisualiser cette version construite :

```powershell
npm.cmd run preview
```

> Sur cette installation de Windows, `npm` est bloqué par la règle d’exécution PowerShell. Utilise `npm.cmd` comme dans les commandes ci-dessus ; il n’est pas nécessaire de modifier cette règle.

## Créer la base de test dans Supabase

1. Crée ou ouvre un projet Supabase hébergé.
2. Dans son **SQL Editor**, exécute les migrations dans l’ordre : `supabase/migrations/20261001120000_create_portail_schema.sql`, `supabase/migrations/20261001170000_enable_backlog_workflows.sql`, puis `supabase/migrations/20261001180000_add_club_dues_and_posters.sql`.
3. Exécute ensuite `supabase/seed.sql` pour insérer les comptes fictifs, clubs, événements, inscriptions et demandes de validation de démonstration. Les deux événements publiés seront visibles ; la demande après 18 h restera privée en attente de validation.
4. Copie `.env.example` vers `.env.local` à la racine du projet.
5. Renseigne `VITE_SUPABASE_URL` et `VITE_SUPABASE_ANON_KEY` avec les valeurs publiques de ton projet Supabase, puis redémarre Vite avec `npm.cmd run dev`.
6. Crée un compte étudiant depuis le formulaire de l’application. Un nouveau compte reçoit toujours le rôle étudiant. Pour tester les écrans BDE ou administration, crée le compte, confirme son adresse si Supabase le demande, puis attribue le rôle voulu à son profil dans `public.utilisateur` avec le SQL Editor du projet.
7. Dans les paramètres **Secrets** de Supabase, configure `GEMINI_API_KEY` et, si nécessaire, `GEMINI_IMAGE_MODEL` (valeur proposée par défaut : `gemini-2.5-flash-image`). Déploie ensuite la fonction `supabase/functions/generate-poster/` avec les outils Supabase. La clé Gemini ne doit jamais être copiée dans `.env.local` ni dans le navigateur.
8. Le déploiement de la fonction nécessite Supabase CLI (commande habituelle : `supabase functions deploy generate-poster`). Cette CLI n’est pas installée sur l’ordinateur pour le moment ; demande l’autorisation avant de l’installer. La clé Gemini se crée dans Google AI Studio et se configure uniquement comme secret de la fonction Supabase.

La page d’accueil lit les événements publiés et les affiches approuvées. L’inscription à un club propose 200 MAD par année scolaire ou 300 MAD pour le cycle Prépa/Ingénieur ; le paiement s’effectue hors du portail et le BDE le confirme manuellement. La confirmation d’inscription au portail apparaît à l’écran ; l’envoi d’un courriel de confirmation n’est pas configuré (aucun fournisseur tel que Gmail API n’a été choisi). Les migrations protègent les opérations par rôle avec RLS et des fonctions SQL.

Ne mets jamais une clé secrète `service_role` dans `.env.local` : les variables `VITE_` sont intégrées dans l’interface et visibles dans le navigateur. Les noms et adresses du jeu de test sont fictifs et utilisent le domaine réservé `example.test`.

## Structure de départ

- `src/` — interface React.
- `src/pages/` — pages de l’application ; `Events.jsx` affiche les événements publiés et `Hello.jsx` reste un exemple de test.
- `src/components/` — composants réutilisables.
- `supabase/functions/generate-poster/` — fonction serveur qui appelle Gemini et garde sa clé hors de l’interface web.
- `src/lib/` — connexion Supabase et fonctions partagées.
- `supabase/migrations/` — scripts SQL de création et d’évolution de la base.
- `supabase/seed.sql` — données fictives de démonstration.
