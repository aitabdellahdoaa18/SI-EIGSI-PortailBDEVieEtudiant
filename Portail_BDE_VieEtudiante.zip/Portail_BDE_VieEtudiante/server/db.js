import { mkdirSync } from 'node:fs';
import { resolve } from 'node:path';
import { DatabaseSync } from 'node:sqlite';
import { randomBytes, scryptSync } from 'node:crypto';

const dataDirectory = resolve(process.cwd(), 'data');
mkdirSync(dataDirectory, { recursive: true });

export const databasePath = resolve(dataDirectory, 'portail-bde.sqlite');
export const db = new DatabaseSync(databasePath);
db.exec('PRAGMA foreign_keys = ON; PRAGMA journal_mode = WAL;');

db.exec(`
  CREATE TABLE IF NOT EXISTS utilisateur (
    id_utilisateur INTEGER PRIMARY KEY AUTOINCREMENT,
    nom TEXT NOT NULL,
    prenom TEXT NOT NULL,
    email TEXT NOT NULL COLLATE NOCASE UNIQUE,
    mot_de_passe_hash TEXT NOT NULL,
    role TEXT NOT NULL CHECK (role IN ('etudiant', 'bde', 'administration')),
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS session (
    token_hash TEXT PRIMARY KEY,
    id_utilisateur INTEGER NOT NULL REFERENCES utilisateur(id_utilisateur) ON DELETE CASCADE,
    expires_at INTEGER NOT NULL
  );

  CREATE TABLE IF NOT EXISTS club (
    id_club INTEGER PRIMARY KEY AUTOINCREMENT,
    nom TEXT NOT NULL UNIQUE,
    description TEXT NOT NULL DEFAULT ''
  );

  CREATE TABLE IF NOT EXISTS evenement (
    id_evenement INTEGER PRIMARY KEY AUTOINCREMENT,
    id_createur INTEGER NOT NULL REFERENCES utilisateur(id_utilisateur) ON DELETE RESTRICT,
    titre TEXT NOT NULL,
    description TEXT NOT NULL DEFAULT '',
    lieu TEXT NOT NULL,
    date_debut TEXT NOT NULL,
    date_fin TEXT,
    capacite_max INTEGER NOT NULL CHECK (capacite_max > 0),
    statut_publication TEXT NOT NULL DEFAULT 'brouillon'
      CHECK (statut_publication IN ('brouillon', 'en_attente_validation', 'publie', 'refuse', 'annule')),
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CHECK (date_fin IS NULL OR date_fin >= date_debut)
  );

  CREATE TABLE IF NOT EXISTS inscription (
    id_inscription INTEGER PRIMARY KEY AUTOINCREMENT,
    id_utilisateur INTEGER NOT NULL REFERENCES utilisateur(id_utilisateur) ON DELETE CASCADE,
    id_evenement INTEGER NOT NULL REFERENCES evenement(id_evenement) ON DELETE CASCADE,
    date_inscription TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    statut_presence TEXT NOT NULL DEFAULT 'a_confirmer'
      CHECK (statut_presence IN ('a_confirmer', 'present', 'absent')),
    UNIQUE (id_utilisateur, id_evenement)
  );

  CREATE TABLE IF NOT EXISTS adhesion (
    id_adhesion INTEGER PRIMARY KEY AUTOINCREMENT,
    id_utilisateur INTEGER NOT NULL REFERENCES utilisateur(id_utilisateur) ON DELETE CASCADE,
    id_club INTEGER NOT NULL REFERENCES club(id_club) ON DELETE CASCADE,
    date_adhesion TEXT NOT NULL DEFAULT (date('now')),
    statut TEXT NOT NULL DEFAULT 'en_attente_paiement'
      CHECK (statut IN ('en_attente_paiement', 'active', 'refusee', 'terminee')),
    plan_cotisation TEXT NOT NULL CHECK (plan_cotisation IN ('annuelle', 'cycle')),
    cycle_etude TEXT CHECK (cycle_etude IS NULL OR cycle_etude IN ('prepa', 'ingenieur')),
    annee_academique TEXT,
    montant_mad INTEGER NOT NULL CHECK (montant_mad IN (200, 300)),
    date_confirmation_paiement TEXT,
    id_confirme_par INTEGER REFERENCES utilisateur(id_utilisateur) ON DELETE SET NULL,
    CHECK (
      (plan_cotisation = 'annuelle' AND cycle_etude IS NULL AND annee_academique IS NOT NULL AND montant_mad = 200)
      OR
      (plan_cotisation = 'cycle' AND cycle_etude IS NOT NULL AND annee_academique IS NULL AND montant_mad = 300)
    ),
    CHECK ((statut = 'active' AND date_confirmation_paiement IS NOT NULL) OR statut <> 'active')
  );

  CREATE UNIQUE INDEX IF NOT EXISTS adhesion_annuelle_unique
    ON adhesion(id_utilisateur, id_club, annee_academique) WHERE plan_cotisation = 'annuelle';
  CREATE UNIQUE INDEX IF NOT EXISTS adhesion_cycle_unique
    ON adhesion(id_utilisateur, id_club, cycle_etude) WHERE plan_cotisation = 'cycle';

  CREATE TABLE IF NOT EXISTS validation (
    id_validation INTEGER PRIMARY KEY AUTOINCREMENT,
    id_evenement INTEGER NOT NULL REFERENCES evenement(id_evenement) ON DELETE CASCADE,
    id_admin INTEGER REFERENCES utilisateur(id_utilisateur) ON DELETE SET NULL,
    statut TEXT NOT NULL DEFAULT 'en_attente' CHECK (statut IN ('en_attente', 'valide', 'refuse')),
    date_demande TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    date_decision TEXT,
    commentaire TEXT NOT NULL DEFAULT ''
  );

  CREATE TABLE IF NOT EXISTS affiche_ia (
    id_affiche INTEGER PRIMARY KEY AUTOINCREMENT,
    id_evenement INTEGER NOT NULL REFERENCES evenement(id_evenement) ON DELETE CASCADE,
    url_image TEXT NOT NULL,
    image BLOB NOT NULL,
    type_image TEXT NOT NULL DEFAULT 'image/png',
    prompt TEXT NOT NULL DEFAULT '',
    date_creation TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    id_generateur INTEGER REFERENCES utilisateur(id_utilisateur) ON DELETE SET NULL,
    id_validateur INTEGER REFERENCES utilisateur(id_utilisateur) ON DELETE SET NULL,
    statut_validation TEXT NOT NULL DEFAULT 'a_verifier'
      CHECK (statut_validation IN ('a_verifier', 'validee', 'refusee'))
  );

  CREATE INDEX IF NOT EXISTS evenement_public_date_idx
    ON evenement(date_debut) WHERE statut_publication = 'publie';
  CREATE INDEX IF NOT EXISTS inscription_event_idx ON inscription(id_evenement);
  CREATE INDEX IF NOT EXISTS validation_pending_idx ON validation(statut, date_demande);
`);

function hashPassword(password) {
  const salt = randomBytes(16);
  const hash = scryptSync(password, salt, 64);
  return `${salt.toString('hex')}:${hash.toString('hex')}`;
}

function createDemoUser(email, firstName, lastName, role, password) {
  const exists = db.prepare('SELECT id_utilisateur FROM utilisateur WHERE email = ?').get(email);
  if (exists) return exists.id_utilisateur;
  const result = db.prepare(`
    INSERT INTO utilisateur (nom, prenom, email, mot_de_passe_hash, role)
    VALUES (?, ?, ?, ?, ?)
  `).run(lastName, firstName, email, hashPassword(password), role);
  return Number(result.lastInsertRowid);
}

function seedDemoData() {
  const studentId = createDemoUser('etudiante@example.test', 'Emma', 'Martin', 'etudiant', 'Etudiante123!');
  const secondStudentId = createDemoUser('etudiant2@example.test', 'Yanis', 'Bernard', 'etudiant', 'Etudiant123!');
  const bdeId = createDemoUser('bde@example.test', 'Sami', 'El Amrani', 'bde', 'BdeDemo123!');
  const adminId = createDemoUser('administration@example.test', 'Nadia', 'Laurent', 'administration', 'AdminDemo123!');

  db.prepare(`INSERT OR IGNORE INTO club (nom, description) VALUES (?, ?)`).run(
    'BDA', 'Bureau des arts et de la culture étudiante.',
  );
  db.prepare(`INSERT OR IGNORE INTO club (nom, description) VALUES (?, ?)`).run(
    'BDS', 'Bureau du développement social et des initiatives associatives.',
  );
  db.prepare(`INSERT OR IGNORE INTO club (nom, description) VALUES (?, ?)`).run(
    'BDE', 'Bureau des élèves et organisateur des événements.',
  );

  if (db.prepare('SELECT COUNT(*) AS count FROM evenement').get().count === 0) {
    const bdaClub = db.prepare('SELECT id_club FROM club WHERE nom = ?').get('BDA').id_club;
    const bdsClub = db.prepare('SELECT id_club FROM club WHERE nom = ?').get('BDS').id_club;
    const bdeClub = db.prepare('SELECT id_club FROM club WHERE nom = ?').get('BDE').id_club;
    const createEvent = db.prepare(`
      INSERT INTO evenement (id_createur, titre, description, lieu, date_debut, date_fin, capacite_max, statut_publication)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `);
    const date = (days, hour) => {
      const value = new Date();
      value.setDate(value.getDate() + days);
      value.setHours(hour, 0, 0, 0);
      return value.toISOString();
    };

    const event1 = Number(createEvent.run(
      bdeId, 'Après-midi de rentrée', 'Rencontre de rentrée organisée par le BDE pour découvrir les associations.',
      'Campus EIGSI — La Rochelle', date(8, 15), date(8, 17), 80, 'publie',
    ).lastInsertRowid);
    const pendingEvent = Number(createEvent.run(
      bdeId, 'Soirée des clubs étudiants', 'Présentation des clubs et échanges entre étudiants.',
      'Campus EIGSI — La Rochelle', date(15, 19), date(15, 22), 120, 'en_attente_validation',
    ).lastInsertRowid);
    const event3 = Number(createEvent.run(
      bdeId, 'Atelier découverte photo', 'Initiation à la photographie proposée par le Club Photo.',
      'Salle associative — Campus EIGSI', date(22, 16), date(22, 18), 20, 'publie',
    ).lastInsertRowid);

    db.prepare(`INSERT INTO validation (id_evenement, statut, commentaire) VALUES (?, 'en_attente', ?)`).run(
      pendingEvent, 'Événement après 18 h : en attente d’examen.',
    );
    db.prepare(`INSERT OR IGNORE INTO inscription (id_utilisateur, id_evenement) VALUES (?, ?)`).run(studentId, event1);
    db.prepare(`INSERT OR IGNORE INTO inscription (id_utilisateur, id_evenement) VALUES (?, ?)`).run(secondStudentId, event1);
    db.prepare(`INSERT OR IGNORE INTO inscription (id_utilisateur, id_evenement) VALUES (?, ?)`).run(studentId, event3);

    const schoolYear = `${new Date().getFullYear()}-${new Date().getFullYear() + 1}`;
    const membership = db.prepare(`
      INSERT OR IGNORE INTO adhesion (
        id_utilisateur, id_club, statut, plan_cotisation, cycle_etude, annee_academique,
        montant_mad, date_confirmation_paiement, id_confirme_par
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    membership.run(studentId, bdaClub, 'active', 'annuelle', null, schoolYear, 200, new Date().toISOString(), bdeId);
    membership.run(secondStudentId, bdsClub, 'active', 'annuelle', null, schoolYear, 200, new Date().toISOString(), bdeId);
    membership.run(secondStudentId, bdaClub, 'en_attente_paiement', 'cycle', 'prepa', null, 300, null, null);
    membership.run(secondStudentId, bdeClub, 'active', 'annuelle', null, schoolYear, 200, new Date().toISOString(), bdeId);
  }

  return { studentId, secondStudentId, bdeId, adminId };
}

export const demoUsers = seedDemoData();

export function createSession(userId, tokenHash, expiresAt) {
  db.prepare('DELETE FROM session WHERE expires_at <= ?').run(Date.now());
  db.prepare('INSERT INTO session (token_hash, id_utilisateur, expires_at) VALUES (?, ?, ?)')
    .run(tokenHash, userId, expiresAt);
}
