import { createServer } from 'node:http';
import { createReadStream, existsSync, readFileSync, statSync } from 'node:fs';
import { extname, resolve, sep } from 'node:path';
import { promisify } from 'node:util';
import {
  createHash,
  randomBytes,
  scrypt,
  timingSafeEqual,
} from 'node:crypto';
import { GoogleGenAI } from '@google/genai';
import { db, createSession, databasePath } from './db.js';

const envPath = resolve(process.cwd(), '.env.local');
if (existsSync(envPath)) {
  const envContent = readFileSync(envPath, 'utf8');
  for (const line of envContent.split(/\r?\n/)) {
    const cleaned = line.trim();
    if (!cleaned || cleaned.startsWith('#')) continue;
    const separatorIndex = cleaned.indexOf('=');
    if (separatorIndex <= 0) continue;
    const key = cleaned.slice(0, separatorIndex).trim();
    const value = cleaned.slice(separatorIndex + 1).trim().replace(/^['"]|['"]$/g, '');
    if (!process.env[key]) process.env[key] = value;
  }
}

const scryptAsync = promisify(scrypt);
const isDevelopment = process.argv.includes('--dev');
const host = '127.0.0.1';
const port = Number(process.env.PORT || 5173);
const sessionMaxAgeMs = 7 * 24 * 60 * 60 * 1000;
let vite = null;

function json(response, status, data, extraHeaders = {}) {
  response.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
    'X-Content-Type-Options': 'nosniff',
    ...extraHeaders,
  });
  response.end(JSON.stringify(data));
}

function parseCookies(request) {
  const cookies = new Map();
  for (const item of (request.headers.cookie || '').split(';')) {
    const separator = item.indexOf('=');
    if (separator < 0) continue;
    cookies.set(item.slice(0, separator).trim(), decodeURIComponent(item.slice(separator + 1).trim()));
  }
  return cookies;
}

function tokenDigest(token) {
  return createHash('sha256').update(token).digest('hex');
}

function findCurrentUser(request) {
  const token = parseCookies(request).get('portail_session');
  if (!token) return null;
  const session = db.prepare(`
    SELECT u.id_utilisateur, u.nom, u.prenom, u.email, u.role, s.expires_at
    FROM session s
    JOIN utilisateur u ON u.id_utilisateur = s.id_utilisateur
    WHERE s.token_hash = ?
  `).get(tokenDigest(token));
  if (!session || session.expires_at <= Date.now()) {
    db.prepare('DELETE FROM session WHERE token_hash = ?').run(tokenDigest(token));
    return null;
  }
  const { expires_at: _expiresAt, ...user } = session;
  return user;
}

function setSessionCookie(response, token) {
  response.setHeader('Set-Cookie', `portail_session=${encodeURIComponent(token)}; HttpOnly; SameSite=Lax; Path=/; Max-Age=${sessionMaxAgeMs / 1000}`);
}

function clearSessionCookie(response) {
  response.setHeader('Set-Cookie', 'portail_session=; HttpOnly; SameSite=Lax; Path=/; Max-Age=0');
}

function requireRole(user, ...roles) {
  if (!user) throw Object.assign(new Error('Connecte-toi pour continuer.'), { status: 401 });
  if (!roles.includes(user.role)) throw Object.assign(new Error('Tu n’as pas le rôle nécessaire pour cette action.'), { status: 403 });
}

async function readJson(request, maxBytes = 1024 * 1024) {
  const chunks = [];
  let size = 0;
  for await (const chunk of request) {
    size += chunk.length;
    if (size > maxBytes) throw Object.assign(new Error('La demande est trop volumineuse.'), { status: 413 });
    chunks.push(chunk);
  }
  if (chunks.length === 0) return {};
  try {
    return JSON.parse(Buffer.concat(chunks).toString('utf8'));
  } catch {
    throw Object.assign(new Error('Les données envoyées ne sont pas valides.'), { status: 400 });
  }
}

function assertSameOrigin(request) {
  const origin = request.headers.origin;
  if (!origin) return;
  const expectedHost = request.headers.host;
  let originHost;
  try { originHost = new URL(origin).host; }
  catch { throw Object.assign(new Error('Origine de la demande invalide.'), { status: 403 }); }
  if (originHost !== expectedHost) {
    throw Object.assign(new Error('Cette demande a été refusée.'), { status: 403 });
  }
}

async function createLoginSession(response, user) {
  const token = randomBytes(32).toString('base64url');
  createSession(user.id_utilisateur, tokenDigest(token), Date.now() + sessionMaxAgeMs);
  setSessionCookie(response, token);
  return { id_utilisateur: user.id_utilisateur, nom: user.nom, prenom: user.prenom, email: user.email, role: user.role };
}

function formatEvent(row) {
  return {
    ...row,
    inscrits: Number(row.inscrits ?? 0),
    affiche_approuvee: row.affiche_approuvee ? Number(row.affiche_approuvee) : null,
  };
}

function getPublicEvents() {
  return db.prepare(`
    SELECT e.id_evenement, e.titre, e.description, e.lieu, e.date_debut, e.date_fin,
      e.capacite_max, e.statut_publication,
      (SELECT COUNT(*) FROM inscription i WHERE i.id_evenement = e.id_evenement) AS inscrits,
      (SELECT a.id_affiche FROM affiche_ia a WHERE a.id_evenement = e.id_evenement
        AND a.statut_validation = 'validee' ORDER BY a.date_creation DESC LIMIT 1) AS affiche_approuvee
    FROM evenement e
    WHERE e.statut_publication = 'publie'
    ORDER BY e.date_debut
  `).all().map(formatEvent);
}

function getEventById(id) {
  return db.prepare('SELECT * FROM evenement WHERE id_evenement = ?').get(id);
}

function isBdeEventOwner(eventId, userId) {
  return Boolean(db.prepare('SELECT 1 FROM evenement WHERE id_evenement = ? AND id_createur = ?').get(eventId, userId));
}

function localStartHour(isoDate) {
  const parts = new Intl.DateTimeFormat('en-GB', {
    timeZone: 'Europe/Paris', hour: '2-digit', minute: '2-digit', hourCycle: 'h23',
  }).formatToParts(new Date(isoDate));
  const hour = Number(parts.find((part) => part.type === 'hour')?.value);
  const minute = Number(parts.find((part) => part.type === 'minute')?.value);
  return hour * 60 + minute;
}

function normalizeMembership(row) {
  return {
    ...row,
    club: { id_club: row.id_club, nom: row.club_nom },
    utilisateur: row.user_id ? {
      id_utilisateur: row.user_id, nom: row.user_nom, prenom: row.user_prenom, email: row.user_email,
    } : undefined,
  };
}

async function handleApi(request, response, url) {
  const path = url.pathname;
  const method = request.method || 'GET';
  if (!['GET', 'HEAD', 'OPTIONS'].includes(method)) assertSameOrigin(request);
  if (method === 'OPTIONS') {
    response.writeHead(204, { 'Allow': 'GET, POST, PATCH, OPTIONS' });
    response.end();
    return;
  }

  const user = findCurrentUser(request);

  if (path === '/api/health' && method === 'GET') {
    json(response, 200, { ok: true, database: 'SQLite', file: databasePath.split(sep).at(-1) });
    return;
  }

  if (path === '/api/auth/session' && method === 'GET') {
    json(response, 200, { user });
    return;
  }

  if (path === '/api/auth/signup' && method === 'POST') {
    const body = await readJson(request);
    const email = String(body.email ?? '').trim().toLowerCase();
    const password = String(body.password ?? '');
    const firstName = String(body.prenom ?? '').trim();
    const lastName = String(body.nom ?? '').trim();
    if (!/^\S+@\S+\.\S+$/.test(email) || password.length < 8 || !firstName || !lastName) {
      json(response, 400, { error: 'Renseigne un nom, un prénom, un courriel valide et un mot de passe d’au moins 8 caractères.' });
      return;
    }
    if (db.prepare('SELECT 1 FROM utilisateur WHERE email = ?').get(email)) {
      json(response, 409, { error: 'Cette adresse courriel possède déjà un compte.' });
      return;
    }
    const salt = randomBytes(16);
    const derived = await scryptAsync(password, salt, 64);
    const result = db.prepare(`
      INSERT INTO utilisateur (nom, prenom, email, mot_de_passe_hash, role)
      VALUES (?, ?, ?, ?, 'etudiant')
    `).run(lastName, firstName, email, `${salt.toString('hex')}:${Buffer.from(derived).toString('hex')}`);
    const newUser = db.prepare('SELECT id_utilisateur, nom, prenom, email, role FROM utilisateur WHERE id_utilisateur = ?')
      .get(Number(result.lastInsertRowid));
    const profile = await createLoginSession(response, newUser);
    json(response, 201, { user: profile, message: 'Compte étudiant créé.' });
    return;
  }

  if (path === '/api/auth/login' && method === 'POST') {
    const body = await readJson(request);
    const email = String(body.email ?? '').trim().toLowerCase();
    const password = String(body.password ?? '');
    const account = db.prepare('SELECT * FROM utilisateur WHERE email = ?').get(email);
    if (!account) {
      json(response, 401, { error: 'Adresse courriel ou mot de passe incorrect.' });
      return;
    }
    const [saltHex, hashHex] = account.mot_de_passe_hash.split(':');
    const candidate = await scryptAsync(password, Buffer.from(saltHex, 'hex'), 64);
    const expected = Buffer.from(hashHex, 'hex');
    if (expected.length !== candidate.length || !timingSafeEqual(expected, Buffer.from(candidate))) {
      json(response, 401, { error: 'Adresse courriel ou mot de passe incorrect.' });
      return;
    }
    const profile = await createLoginSession(response, account);
    json(response, 200, { user: profile, message: 'Connexion réussie.' });
    return;
  }

  if (path === '/api/auth/logout' && method === 'POST') {
    const token = parseCookies(request).get('portail_session');
    if (token) db.prepare('DELETE FROM session WHERE token_hash = ?').run(tokenDigest(token));
    clearSessionCookie(response);
    json(response, 200, { ok: true });
    return;
  }

  if (path === '/api/auth/me' && method === 'GET') {
    if (!user) {
      json(response, 401, { error: 'Session absente ou expirée.' });
      return;
    }
    json(response, 200, { user });
    return;
  }

  if (path === '/api/events' && method === 'GET') {
    json(response, 200, { events: getPublicEvents() });
    return;
  }

  if (path === '/api/clubs' && method === 'GET') {
    const clubs = db.prepare('SELECT id_club, nom, description FROM club ORDER BY nom').all();
    json(response, 200, { clubs });
    return;
  }

  if (path === '/api/me/memberships' && method === 'GET') {
    requireRole(user, 'etudiant');
    const rows = db.prepare(`
      SELECT a.*, c.nom AS club_nom
      FROM adhesion a JOIN club c ON c.id_club = a.id_club
      WHERE a.id_utilisateur = ? ORDER BY a.date_adhesion DESC
    `).all(user.id_utilisateur);
    json(response, 200, { memberships: rows.map(normalizeMembership) });
    return;
  }

  if (path === '/api/memberships' && method === 'POST') {
    requireRole(user, 'etudiant');
    const body = await readJson(request);
    const clubId = Number(body.clubId);
    const plan = String(body.plan ?? '');
    const cycle = body.cycle === null ? null : String(body.cycle ?? '');
    const club = db.prepare('SELECT id_club FROM club WHERE id_club = ?').get(clubId);
    if (!club) {
      json(response, 404, { error: 'Club introuvable.' });
      return;
    }
    let amount;
    let schoolYear = null;
    if (plan === 'annuelle' && !cycle) {
      amount = 200;
      const dateParts = new Intl.DateTimeFormat('en-CA', { timeZone: 'Africa/Casablanca', year: 'numeric', month: '2-digit' })
        .formatToParts(new Date());
      const year = Number(dateParts.find((part) => part.type === 'year')?.value);
      const month = Number(dateParts.find((part) => part.type === 'month')?.value);
      schoolYear = month >= 9 ? `${year}-${year + 1}` : `${year - 1}-${year}`;
    } else if (plan === 'cycle' && ['prepa', 'ingenieur'].includes(cycle)) {
      amount = 300;
    } else {
      json(response, 400, { error: 'Choisis 200 MAD par année ou 300 MAD pour le cycle Prépa ou Ingénieur.' });
      return;
    }
    try {
      const result = db.prepare(`
        INSERT INTO adhesion (id_utilisateur, id_club, statut, plan_cotisation, cycle_etude, annee_academique, montant_mad)
        VALUES (?, ?, 'en_attente_paiement', ?, ?, ?, ?)
      `).run(user.id_utilisateur, clubId, plan, plan === 'cycle' ? cycle : null, schoolYear, amount);
      json(response, 201, { id_adhesion: Number(result.lastInsertRowid), message: 'Demande enregistrée.' });
    } catch (error) {
      if (error.code === 'ERR_SQLITE_ERROR' && String(error.message).includes('UNIQUE')) {
        json(response, 409, { error: 'Une cotisation pour cette formule existe déjà pour ce club.' });
      } else throw error;
    }
    return;
  }

  if (path === '/api/bde/events' && method === 'GET') {
    requireRole(user, 'bde');
    const rows = db.prepare(`
      SELECT e.*, (SELECT COUNT(*) FROM inscription i WHERE i.id_evenement = e.id_evenement) AS inscrits
      FROM evenement e WHERE e.id_createur = ? ORDER BY e.date_debut
    `).all(user.id_utilisateur).map(formatEvent);
    json(response, 200, { events: rows });
    return;
  }

  if (path === '/api/bde/events' && method === 'POST') {
    requireRole(user, 'bde');
    const body = await readJson(request);
    const title = String(body.titre ?? '').trim();
    const venue = String(body.lieu ?? '').trim();
    const startsAt = String(body.date_debut ?? '');
    const endsAt = body.date_fin ? String(body.date_fin) : null;
    const capacity = Number(body.capacite_max);
    if (!title || !venue || !startsAt || !Number.isInteger(capacity) || capacity < 1
      || Number.isNaN(new Date(startsAt).getTime())
      || (endsAt && (Number.isNaN(new Date(endsAt).getTime()) || endsAt < startsAt))) {
      json(response, 400, { error: 'Vérifie le titre, la date, le lieu et la capacité (au moins une place).' });
      return;
    }
    const needsApproval = localStartHour(startsAt) >= 18 * 60;
    db.exec('BEGIN IMMEDIATE');
    try {
      const result = db.prepare(`
        INSERT INTO evenement (id_createur, titre, description, lieu, date_debut, date_fin, capacite_max, statut_publication)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
      `).run(user.id_utilisateur, title, String(body.description ?? '').trim(), venue, startsAt, endsAt, capacity,
        needsApproval ? 'en_attente_validation' : 'publie');
      const eventId = Number(result.lastInsertRowid);
      if (needsApproval) {
        db.prepare(`INSERT INTO validation (id_evenement, statut, commentaire) VALUES (?, 'en_attente', ?)`).run(
          eventId, 'Validation nécessaire : début à 18 h ou après (heure de Paris).',
        );
      }
      db.exec('COMMIT');
      json(response, 201, { id_evenement: eventId, statut_publication: needsApproval ? 'en_attente_validation' : 'publie' });
    } catch (error) {
      db.exec('ROLLBACK');
      throw error;
    }
    return;
  }

  const publicRegistrationMatch = path.match(/^\/api\/events\/(\d+)\/registrations$/);
  if (publicRegistrationMatch && method === 'POST') {
    requireRole(user, 'etudiant');
    const eventId = Number(publicRegistrationMatch[1]);
    db.exec('BEGIN IMMEDIATE');
    try {
      const event = db.prepare(`SELECT * FROM evenement WHERE id_evenement = ? AND statut_publication = 'publie'`).get(eventId);
      if (!event) {
        db.exec('ROLLBACK');
        json(response, 404, { error: 'Cet événement n’est pas ouvert aux inscriptions.' });
        return;
      }
      const alreadyRegistered = db.prepare('SELECT 1 FROM inscription WHERE id_utilisateur = ? AND id_evenement = ?')
        .get(user.id_utilisateur, eventId);
      if (alreadyRegistered) {
        db.exec('ROLLBACK');
        json(response, 409, { error: 'Tu es déjà inscrit à cet événement.' });
        return;
      }
      const count = db.prepare('SELECT COUNT(*) AS count FROM inscription WHERE id_evenement = ?').get(eventId).count;
      if (count >= event.capacite_max) {
        db.exec('ROLLBACK');
        json(response, 409, { error: 'Cet événement a atteint sa capacité maximale.' });
        return;
      }
      const result = db.prepare('INSERT INTO inscription (id_utilisateur, id_evenement) VALUES (?, ?)')
        .run(user.id_utilisateur, eventId);
      db.exec('COMMIT');
      json(response, 201, { id_inscription: Number(result.lastInsertRowid), message: 'Inscription enregistrée.' });
    } catch (error) {
      if (db.isTransaction) db.exec('ROLLBACK');
      throw error;
    }
    return;
  }

  const registrationsMatch = path.match(/^\/api\/bde\/events\/(\d+)\/registrations$/);
  if (registrationsMatch && method === 'GET') {
    requireRole(user, 'bde', 'administration');
    const eventId = Number(registrationsMatch[1]);
    if (user.role === 'bde' && !isBdeEventOwner(eventId, user.id_utilisateur)) {
      json(response, 403, { error: 'Tu ne peux consulter que tes propres événements.' });
      return;
    }
    const registrations = db.prepare(`
      SELECT i.id_inscription, i.date_inscription, i.statut_presence,
        u.id_utilisateur, u.nom, u.prenom, u.email
      FROM inscription i JOIN utilisateur u ON u.id_utilisateur = i.id_utilisateur
      WHERE i.id_evenement = ? ORDER BY i.date_inscription
    `).all(eventId).map((row) => ({
      id_inscription: row.id_inscription,
      date_inscription: row.date_inscription,
      statut_presence: row.statut_presence,
      utilisateur: { id_utilisateur: row.id_utilisateur, nom: row.nom, prenom: row.prenom, email: row.email },
    }));
    json(response, 200, { registrations });
    return;
  }

  const attendanceMatch = path.match(/^\/api\/bde\/registrations\/(\d+)\/attendance$/);
  if (attendanceMatch && method === 'PATCH') {
    requireRole(user, 'bde', 'administration');
    const body = await readJson(request);
    const status = String(body.statut ?? '');
    if (!['present', 'absent', 'a_confirmer'].includes(status)) {
      json(response, 400, { error: 'Choisis présent, absent ou à confirmer.' });
      return;
    }
    const registration = db.prepare(`
      SELECT i.id_evenement FROM inscription i WHERE i.id_inscription = ?
    `).get(Number(attendanceMatch[1]));
    if (!registration || (user.role === 'bde' && !isBdeEventOwner(registration.id_evenement, user.id_utilisateur))) {
      json(response, 404, { error: 'Inscription introuvable ou accès refusé.' });
      return;
    }
    db.prepare('UPDATE inscription SET statut_presence = ? WHERE id_inscription = ?').run(status, Number(attendanceMatch[1]));
    json(response, 200, { ok: true });
    return;
  }

  if (path === '/api/admin/validations' && method === 'GET') {
    requireRole(user, 'administration');
    const requests = db.prepare(`
      SELECT v.id_validation, v.date_demande, v.commentaire, v.statut,
        e.id_evenement, e.titre, e.lieu, e.date_debut, e.capacite_max
      FROM validation v JOIN evenement e ON e.id_evenement = v.id_evenement
      WHERE v.statut = 'en_attente' ORDER BY v.date_demande
    `).all().map((row) => ({
      id_validation: row.id_validation,
      date_demande: row.date_demande,
      commentaire: row.commentaire,
      statut: row.statut,
      evenement: {
        id_evenement: row.id_evenement, titre: row.titre, lieu: row.lieu,
        date_debut: row.date_debut, capacite_max: row.capacite_max,
      },
    }));
    json(response, 200, { requests });
    return;
  }

  const validationMatch = path.match(/^\/api\/admin\/validations\/(\d+)$/);
  if (validationMatch && method === 'POST') {
    requireRole(user, 'administration');
    const body = await readJson(request);
    const decision = String(body.decision ?? '');
    if (!['valide', 'refuse'].includes(decision)) {
      json(response, 400, { error: 'Choisis valider ou refuser.' });
      return;
    }
    const validation = db.prepare(`SELECT id_evenement FROM validation WHERE id_validation = ? AND statut = 'en_attente'`)
      .get(Number(validationMatch[1]));
    if (!validation) {
      json(response, 404, { error: 'Demande introuvable ou déjà traitée.' });
      return;
    }
    db.exec('BEGIN IMMEDIATE');
    try {
      db.prepare(`UPDATE validation SET statut = ?, id_admin = ?, date_decision = CURRENT_TIMESTAMP WHERE id_validation = ?`)
        .run(decision, user.id_utilisateur, Number(validationMatch[1]));
      db.prepare('UPDATE evenement SET statut_publication = ? WHERE id_evenement = ?')
        .run(decision === 'valide' ? 'publie' : 'refuse', validation.id_evenement);
      db.exec('COMMIT');
    } catch (error) {
      db.exec('ROLLBACK');
      throw error;
    }
    json(response, 200, { ok: true });
    return;
  }

  if (path === '/api/admin/statistics' && method === 'GET') {
    requireRole(user, 'administration');
    const events = db.prepare('SELECT COUNT(*) AS count FROM evenement').get().count;
    const registrations = db.prepare('SELECT COUNT(*) AS count FROM inscription').get().count;
    const present = db.prepare(`SELECT COUNT(*) AS count FROM inscription WHERE statut_presence = 'present'`).get().count;
    const registeredPeople = db.prepare(`
      SELECT DISTINCT u.id_utilisateur, u.nom, u.prenom
      FROM inscription i
      JOIN utilisateur u ON u.id_utilisateur = i.id_utilisateur
      ORDER BY u.nom, u.prenom
    `).all();
    const presentPeople = db.prepare(`
      SELECT DISTINCT u.id_utilisateur, u.nom, u.prenom
      FROM inscription i
      JOIN utilisateur u ON u.id_utilisateur = i.id_utilisateur
      WHERE i.statut_presence = 'present'
      ORDER BY u.nom, u.prenom
    `).all();
    json(response, 200, { events, registrations, present, registeredPeople, presentPeople });
    return;
  }

  if (path === '/api/bde/memberships/pending' && method === 'GET') {
    requireRole(user, 'bde', 'administration');
    const memberships = db.prepare(`
      SELECT a.*, c.nom AS club_nom, u.id_utilisateur AS user_id, u.nom AS user_nom,
        u.prenom AS user_prenom, u.email AS user_email
      FROM adhesion a
      JOIN club c ON c.id_club = a.id_club
      JOIN utilisateur u ON u.id_utilisateur = a.id_utilisateur
      WHERE a.statut = 'en_attente_paiement' ORDER BY a.date_adhesion
    `).all().map(normalizeMembership);
    json(response, 200, { memberships });
    return;
  }

  const paymentMatch = path.match(/^\/api\/bde\/memberships\/(\d+)\/confirm$/);
  if (paymentMatch && method === 'POST') {
    requireRole(user, 'bde', 'administration');
    const result = db.prepare(`
      UPDATE adhesion SET statut = 'active', date_confirmation_paiement = CURRENT_TIMESTAMP,
        id_confirme_par = ? WHERE id_adhesion = ? AND statut = 'en_attente_paiement'
    `).run(user.id_utilisateur, Number(paymentMatch[1]));
    if (result.changes === 0) {
      json(response, 404, { error: 'Demande introuvable ou déjà confirmée.' });
      return;
    }
    json(response, 200, { ok: true });
    return;
  }

  if (path === '/api/bde/posters' && method === 'GET') {
    requireRole(user, 'bde');
    const posters = db.prepare(`
      SELECT a.id_affiche, a.id_evenement, a.url_image, a.prompt, a.statut_validation,
        e.titre AS evenement_titre
      FROM affiche_ia a JOIN evenement e ON e.id_evenement = a.id_evenement
      WHERE a.id_generateur = ? ORDER BY a.date_creation DESC
    `).all(user.id_utilisateur).map((row) => ({
      id_affiche: row.id_affiche, id_evenement: row.id_evenement,
      url_image: row.url_image, prompt: row.prompt, statut_validation: row.statut_validation,
      evenement: { titre: row.evenement_titre },
    }));
    json(response, 200, { posters });
    return;
  }

  const posterImageMatch = path.match(/^\/api\/posters\/(\d+)\/image$/);
  if (posterImageMatch && method === 'GET') {
    const poster = db.prepare(`
      SELECT a.image, a.type_image, a.statut_validation, e.id_createur
      FROM affiche_ia a JOIN evenement e ON e.id_evenement = a.id_evenement
      WHERE a.id_affiche = ?
    `).get(Number(posterImageMatch[1]));
    if (!poster || (poster.statut_validation !== 'validee'
      && (!user || (user.role !== 'administration' && poster.id_createur !== user.id_utilisateur)))) {
      json(response, 404, { error: 'Image introuvable.' });
      return;
    }
    response.writeHead(200, { 'Content-Type': poster.type_image, 'Cache-Control': 'private, max-age=300', 'X-Content-Type-Options': 'nosniff' });
    response.end(poster.image);
    return;
  }

  const posterDecisionMatch = path.match(/^\/api\/bde\/posters\/(\d+)$/);
  if (posterDecisionMatch && method === 'POST') {
    requireRole(user, 'bde');
    const body = await readJson(request);
    const decision = String(body.decision ?? '');
    if (!['validee', 'refusee'].includes(decision)) {
      json(response, 400, { error: 'Choisis valider ou refuser.' });
      return;
    }
    const poster = db.prepare(`
      SELECT a.id_affiche, a.statut_validation, e.id_createur
      FROM affiche_ia a JOIN evenement e ON e.id_evenement = a.id_evenement
      WHERE a.id_affiche = ?
    `).get(Number(posterDecisionMatch[1]));
    if (!poster || poster.id_createur !== user.id_utilisateur || poster.statut_validation !== 'a_verifier') {
      json(response, 404, { error: 'Affiche introuvable ou accès refusé.' });
      return;
    }
    db.prepare('UPDATE affiche_ia SET statut_validation = ?, id_validateur = ? WHERE id_affiche = ?')
      .run(decision, user.id_utilisateur, poster.id_affiche);
    json(response, 200, { ok: true });
    return;
  }

  if (path === '/api/posters/generate' && method === 'POST') {
    requireRole(user, 'bde');
    const body = await readJson(request);
    const eventId = Number(body.eventId);
    const prompt = String(body.prompt ?? '').trim();
    const event = getEventById(eventId);
    if (!event || event.id_createur !== user.id_utilisateur) {
      json(response, 404, { error: 'Événement introuvable ou accès refusé.' });
      return;
    }
    if (prompt.length < 10 || prompt.length > 1500) {
      json(response, 400, { error: 'Décris le style de l’affiche en 10 à 1500 caractères.' });
      return;
    }
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      json(response, 503, { error: 'Ajoute GEMINI_API_KEY dans .env.local pour activer la génération.' });
      return;
    }
    const preferredModels = Array.from(new Set([
      process.env.GEMINI_IMAGE_MODEL,
      'gemini-2.5-flash-image',
      'gemini-2.0-flash-preview-image-generation',
    ].filter(Boolean)));
    const promptForModel = [
      'Create a polished student event poster illustration for an engineering school in La Rochelle.',
      'Do not render text, logos or fake lettering; the application displays event details separately.',
      `Event: ${event.titre}. Place: ${event.lieu}. Description: ${event.description}.`,
      `Visual direction: ${prompt}`,
    ].join('\n');

    const gemini = new GoogleGenAI({ apiKey });
    let generated = null;
    let imagePart = null;
    let lastErrorText = '';
    let chosenModel = '';

    for (const model of preferredModels) {
      try {
        chosenModel = model;
        generated = await gemini.models.generateContent({
          model,
          contents: promptForModel,
          config: { responseModalities: ['TEXT', 'IMAGE'] },
        });

        imagePart = (generated?.candidates?.[0]?.content?.parts ?? [])
          .find((part) => part.inlineData?.data || part.inline_data?.data);

        if (imagePart) {
          break;
        }

        lastErrorText = 'Le modèle a répondu, mais n’a pas renvoyé de partie image.';
        console.error('Gemini returned no image for model', model);
        generated = null;
      } catch (error) {
        const status = Number(error?.status) || 0;
        lastErrorText = error instanceof Error ? error.message : String(error);
        console.error('Gemini SDK error for model', model, status, lastErrorText);
        generated = null;
      }
    }

    if (!generated) {
      const detail = lastErrorText || 'Réponse vide du service.';
      json(response, 502, {
        error: `Gemini n’a pas pu générer l’image. Détail exact Google: ${detail}`,
      });
      return;
    }

    const imageData = imagePart?.inlineData?.data ?? imagePart?.inline_data?.data;
    if (!imageData) {
      json(response, 502, { error: `Gemini n’a renvoyé aucune image pour le modèle ${chosenModel}.` });
      return;
    }
    const mimeType = imagePart?.inlineData?.mimeType || imagePart?.inline_data?.mimeType || 'image/png';
    if (!['image/png', 'image/jpeg', 'image/webp'].includes(mimeType)) {
      json(response, 502, { error: 'Gemini a renvoyé un format d’image non pris en charge.' });
      return;
    }
    const image = Buffer.from(imageData, 'base64');
    if (image.length > 10 * 1024 * 1024) {
      json(response, 502, { error: 'L’image générée dépasse la taille autorisée.' });
      return;
    }
    const filename = `${eventId}/${randomBytes(12).toString('hex')}.${mimeType === 'image/jpeg' ? 'jpg' : mimeType === 'image/webp' ? 'webp' : 'png'}`;
    const result = db.prepare(`
      INSERT INTO affiche_ia (id_evenement, url_image, image, type_image, prompt, id_generateur)
      VALUES (?, ?, ?, ?, ?, ?)
    `).run(eventId, filename, image, mimeType, prompt, user.id_utilisateur);
    json(response, 201, { posterId: Number(result.lastInsertRowid), status: 'a_verifier' });
    return;
  }

  json(response, 404, { error: 'Adresse API introuvable.' });
}

const mimeTypes = {
  '.css': 'text/css; charset=utf-8', '.html': 'text/html; charset=utf-8',
  '.ico': 'image/x-icon', '.js': 'text/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8', '.png': 'image/png',
  '.svg': 'image/svg+xml', '.webp': 'image/webp',
};

async function serveProductionFile(request, response, url) {
  const distDirectory = resolve(process.cwd(), 'dist');
  const requestedPath = decodeURIComponent(url.pathname === '/' ? '/index.html' : url.pathname);
  let filePath = resolve(distDirectory, `.${requestedPath}`);
  if (!filePath.startsWith(`${distDirectory}${sep}`) && filePath !== resolve(distDirectory, 'index.html')) {
    json(response, 403, { error: 'Accès refusé.' });
    return;
  }
  if (!existsSync(filePath) || !statSync(filePath).isFile()) filePath = resolve(distDirectory, 'index.html');
  if (!existsSync(filePath)) {
    json(response, 503, { error: 'La page compilée est absente. Lance la compilation du projet.' });
    return;
  }
  response.writeHead(200, { 'Content-Type': mimeTypes[extname(filePath)] || 'application/octet-stream' });
  createReadStream(filePath).pipe(response);
}

async function main() {
  const httpServer = createServer(async (request, response) => {
    const url = new URL(request.url || '/', `http://${request.headers.host || `${host}:${port}`}`);
    if (url.pathname.startsWith('/api/')) {
      try {
        await handleApi(request, response, url);
      } catch (error) {
        if (response.headersSent) {
          response.destroy();
          return;
        }
        const status = Number(error.status) || 500;
        if (status >= 500) console.error('API error:', error);
        json(response, status, { error: status >= 500 ? 'Une erreur est survenue sur le serveur local.' : error.message });
      }
      return;
    }

    if (isDevelopment) {
      vite.middlewares(request, response, (error) => {
        if (error) {
          console.error('Vite error:', error);
          if (!response.headersSent) json(response, 500, { error: 'Impossible de servir l’application.' });
        } else if (!response.headersSent) {
          json(response, 404, { error: 'Page introuvable.' });
        }
      });
      return;
    }

    try { await serveProductionFile(request, response, url); }
    catch (error) { console.error('Static file error:', error); json(response, 400, { error: 'Adresse invalide.' }); }
  });

  if (isDevelopment) {
    const { createServer: createViteServer } = await import('vite');
    vite = await createViteServer({
      configFile: resolve(process.cwd(), 'vite.config.js'),
      server: { middlewareMode: true, hmr: { server: httpServer } },
      appType: 'spa',
    });
  }

  httpServer.listen(port, host, () => {
    console.log(`Portail BDE prêt : http://${host}:${port}/`);
    console.log(`Base SQLite locale : ${databasePath}`);
    if (process.env.GEMINI_API_KEY) {
      console.log('Gemini activé : génération d’affiches IA disponible.');
    } else {
      console.log('Gemini désactivé : ajoute GEMINI_API_KEY dans .env.local pour les affiches IA.');
    }
    if (isDevelopment) {
      console.log('Comptes de démonstration : etudiante@example.test / Etudiante123! ; bde@example.test / BdeDemo123! ; administration@example.test / AdminDemo123!');
    }
  });

  process.on('SIGINT', () => { vite?.close(); httpServer.close(() => process.exit(0)); });
  process.on('SIGTERM', () => { vite?.close(); httpServer.close(() => process.exit(0)); });
}

main().catch((error) => {
  console.error('Impossible de démarrer le portail :', error);
  process.exitCode = 1;
});
