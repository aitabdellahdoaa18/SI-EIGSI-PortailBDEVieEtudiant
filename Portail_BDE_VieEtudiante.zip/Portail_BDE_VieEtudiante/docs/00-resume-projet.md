# Résumé du projet — Portail BDE / Vie étudiante

## 1. Résumé de l’application (7 lignes)
- Le projet vise un portail unique pour les activités de la vie étudiante de l’EIGSI.
- Les étudiants peuvent consulter les événements, s’y inscrire et adhérer aux clubs.
- Le BDE peut créer et publier des événements, puis suivre les inscriptions et la participation.
- Les événements prévus après 18 h doivent être soumis à l’administration pour approbation ou refus.
- Le portail doit envoyer des confirmations et fournir des chiffres utiles au suivi des activités.
- Une génération d’affiches par IA est aussi envisagée, avec validation humaine avant diffusion.
- La conception propose React/Vite, Node.js/Express et PostgreSQL via Supabase.

## 2. Inventaire des fichiers et éléments manquants

### Fichiers trouvés
- [S1_Rapport_Portail_BDE_Vie_Etudiant-.pdf](../S1_Rapport_Portail_BDE_Vie_Etudiant-.pdf) — cadrage, retour d’entretien, processus BPMN, priorités et indicateurs de suivi.
- [S2_Rapport_Portail_BDE_Vie_Etudiante_.pdf](../S2_Rapport_Portail_BDE_Vie_Etudiante_.pdf) — user stories du MVP, correspondance avec les écrans, architecture et extrait du dictionnaire de données.
- [Wireframes.png](../Wireframes.png) — trois maquettes : événements/inscriptions, création et suivi, demandes à valider.
- [BPMN-TO-BE.png](../BPMN-TO-BE.png) — processus cible avec les couloirs étudiant, BDE et administration.
- [MCD.jpg](../MCD.jpg) — modèle de données montrant sept entités : utilisateur, événement, club, adhésion, inscription, validation et affiche IA.
- [choix-stack.jpg](../choix-stack.jpg) — schéma d’architecture en trois couches et technologies envisagées.

### Éléments non trouvés séparément
- Le backlog est présent dans le rapport S2, mais aucun fichier de backlog modifiable (tableur ou outil de suivi) n’a été trouvé.
- Aucun schéma de base de données exécutable (SQL), ni règles détaillées de champs/contraintes, n’a été trouvé.
- Aucun code source, dépôt applicatif, guide d’installation ou fichier de configuration n’a été trouvé.
- Aucun détail suffisant sur le paiement, les tarifs, les capacités maximales, la présence réelle aux événements ou la gestion des notifications n’a été trouvé.
- Les cibles chiffrées des indicateurs et la priorité MoSCoW attribuée à chaque user story ne sont pas clairement disponibles dans les éléments consultés.

## 3. Incohérences et points à clarifier

- **Périmètre du MVP variable :** le rapport S2 présente les adhésions, confirmations automatiques, statistiques et suivi en temps réel comme des compléments, alors que les maquettes et leur tableau de correspondance incluent certaines de ces fonctions dans les écrans du MVP.
- **Billetterie sans paiement défini :** le rapport S1 en fait une priorité, mais les maquettes montrent surtout une inscription et le MCD ne décrit ni paiement, ni tarif, ni billet.
- **Capacité affichée mais absente du modèle :** la maquette de création/suivi montre une progression du type « 42 / 60 », mais le MCD ne prévoit pas de nombre maximal de places pour un événement.
- **Participation différente d’une inscription :** le BDE doit faire un bilan de participation, mais le modèle stocke des inscriptions sans préciser si la personne a réellement assisté à l’événement.
- **Règle des 18 h :** le BPMN et les rapports prévoient une approbation pour les événements après 18 h. Le MCD contient une validation et une date de début, mais la règle exacte (heure locale, événement commençant ou se terminant après 18 h, cas à 18 h pile) n’est pas précisée.
- **Événement annulé :** le BPMN prévoit une fin « événement annulé », mais les statuts cités dans le dictionnaire du MCD ne comprennent pas clairement cet état.
- **Affiches IA pas alignées entre les livrables :** l’affiche IA apparaît dans le backlog et le MCD, et le choix de stack la décrit comme optionnelle, mais son parcours n’est pas visible dans les trois maquettes ni clairement intégré au BPMN.
- **Adhésion à un club peu détaillée :** elle figure dans le BPMN, le backlog et le MCD, mais aucune maquette dédiée ni règles d’approbation, de cotisation ou de période d’adhésion ne sont définies.

## 4. Questions pour avancer (5 maximum)
1. Quelles fonctions doivent absolument être livrées dans la première version : adhésion, confirmation, statistiques, affiche IA et suivi en temps réel ?
2. La « billetterie » implique-t-elle un paiement, et faut-il définir un tarif et un nombre maximal de places pour chaque événement ?
3. Comment le BDE enregistrera-t-il la présence réelle, afin de la distinguer d’une simple inscription ?
4. Pour la règle des 18 h, quelle heure doit être vérifiée et que se passe-t-il pour un événement qui commence exactement à 18 h ?
5. Souhaitez-vous un seul rôle « BDE » ou plusieurs rôles distincts (organisateur, responsable qui valide une affiche, etc.) ?
