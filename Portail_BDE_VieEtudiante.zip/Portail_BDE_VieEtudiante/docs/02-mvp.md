# Périmètre du MVP — Portail BDE / Vie étudiante

## Objectif

Réaliser une première version petite mais démontrable : le BDE crée un événement, l’administration le traite si une validation est nécessaire, l’étudiant consulte les événements publiés et s’inscrit, puis le BDE voit les inscriptions.

## 1. Classement des fonctionnalités

### Indispensable — cinq fonctionnalités

1. **Consulter les événements publiés (US01–US02)** : afficher une liste simple triée par date, avec les informations principales.
2. **Créer, faire valider et publier un événement (US06–US11)** : permettre au BDE de créer un événement et à l’administration de l’approuver ou de le refuser lorsque la règle de validation s’applique.
3. **S’inscrire à un événement (US03)** : permettre à un étudiant de s’inscrire une seule fois au même événement.
4. **Suivre les inscriptions côté BDE (US12)** : afficher les inscrits et leur nombre ; une actualisation manuelle suffit au MVP.
5. **Séparer les accès étudiant, BDE et administration** : ce besoin technique n’est pas une story distincte, mais il est nécessaire pour réserver les actions aux bons rôles.

### Utile, à ajouter après le parcours principal

- **Confirmation d’inscription (US05)** : commencer par un message affiché à l’écran ; ajouter les courriels ensuite.
- **Bilan de participation réelle (US13)** : distinguer les personnes inscrites des personnes présentes.
- **Statistiques (US14)** : commencer par des compteurs simples ; les statistiques de présence attendront le pointage.

### Plus tard

- **Adhésion à un club (US04)** : les règles de cotisation, de renouvellement et d’approbation restent à définir.
- **Génération d’affiche par IA (IA-01)** : fonctionnalité complémentaire qui dépend d’un service supplémentaire.

> Le rapport S1 met en avant la billetterie et l’adhésion comme besoins terrain, tandis que le rapport S2 présente l’adhésion comme un enrichissement qui ne bloque pas le parcours MVP. Ce plan la reporte pour limiter la première version ; le BDE peut décider qu’elle doit être prioritaire.

## 2. Étapes de réalisation, de la plus simple à la plus complexe

1. **Maquetter les pages avec de fausses données** : préparer une liste d’événements, un formulaire de création et un écran de validation. Vérifier le parcours avant de connecter la base.
2. **Afficher les événements publiés depuis la base** : connecter l’interface à Supabase et ne présenter que les événements visibles par les étudiants.
3. **Créer les accès par rôle** : prévoir les profils étudiant, BDE et administration, puis vérifier les actions permises pour chacun.
4. **Créer et traiter un événement** : le BDE enregistre l’événement ; l’administration peut approuver ou refuser la demande si nécessaire ; seul un événement autorisé est publié.
5. **Ajouter les inscriptions** : permettre à un étudiant connecté de s’inscrire et empêcher une inscription en double au même événement.
6. **Ajouter le suivi du BDE** : afficher la liste des inscrits et le nombre total ; un bouton d’actualisation convient pour la première version.

### Parcours de démonstration

**Le BDE crée un événement → l’administration prend sa décision si nécessaire → l’événement est publié → un étudiant le consulte et s’inscrit → le BDE voit l’inscription et le total.**

## 3. Stack technique recommandée

La stack décrite dans les documents est React/Vite/Tailwind, Node.js/Express et PostgreSQL via Supabase. Elle est adaptée au produit, mais toutes ces parties à apprendre et à maintenir en même temps peuvent être lourdes pour un débutant.

Pour le premier MVP, je recommande une version plus simple de cette stack :

- **Interface : React + Vite.**
- **Base et authentification : Supabase hébergé, avec PostgreSQL.**
- **Serveur Node.js/Express : reporté.** L’interface peut appeler Supabase directement ; un serveur distinct pourra être ajouté plus tard si le projet a besoin de traitements serveur spécifiques.
- **Style : CSS simple**, sauf si Tailwind est déjà configuré ou familier.

Cette simplification retire un serveur à construire et à héberger. Elle ne retire pas le besoin de protéger les données : les règles d’accès Supabase doivent être configurées et testées par rôle. Ne jamais placer une clé secrète de service dans le code exécuté dans le navigateur. Un projet Supabase hébergé est plus facile à démarrer qu’une installation locale avec Docker ; l’interface, elle, peut tourner sur l’ordinateur pendant le développement.

## 4. Hypothèses et décisions à confirmer

- Pour ce MVP, la « billetterie » est considérée comme une inscription sans paiement : les documents ne définissent pas les tarifs ni les règles de paiement.
- Avant de coder la règle des événements après 18 h, préciser si l’heure concernée est celle du début ou de la fin et ce qui se passe exactement à 18 h.
- La capacité maximale n’est pas incluse tant que la limite de places et sa règle d’application ne sont pas confirmées.
- Une inscription ne prouve pas qu’une personne est venue ; le pointage et le bilan de présence sont reportés.
- Le temps réel, les courriels automatiques, l’adhésion aux clubs, les statistiques détaillées et les affiches IA sont hors du premier parcours.

## Sources de cadrage

- Rapport S1 : besoins terrain, priorité billetterie/adhésion et processus d’approbation après 18 h.
- Rapport S2 : backlog US01–US14 et IA-01, maquettes, architecture et modèle de données.
- Maquettes et schémas : [Wireframes.png](../Wireframes.png), [BPMN-TO-BE.png](../BPMN-TO-BE.png) et [choix-stack.jpg](../choix-stack.jpg).
