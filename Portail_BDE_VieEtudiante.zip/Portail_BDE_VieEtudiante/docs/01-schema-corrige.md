# Proposition de schéma corrigé — Portail BDE / Vie étudiante

> Proposition issue de la relecture du MCD et des rapports. Elle précise les clés, les liens et les règles importantes, sans imposer de choix encore incertains comme le paiement.

## 1. Tables proposées

### `UTILISATEUR`
- `id_utilisateur` — clé primaire.
- `nom`, `prenom` — nom et prénom.
- `email` — obligatoire et unique.
- `role` — rôle parmi `etudiant`, `bde`, `administration`.
- Authentification : si Supabase la gère, ne pas stocker de mot de passe dans cette table. Sinon, ne conserver qu’un mot de passe protégé par un hachage adapté, jamais le mot de passe lisible.

### `EVENEMENT`
- `id_evenement` — clé primaire.
- `id_createur` — clé étrangère vers `UTILISATEUR.id_utilisateur`.
- `titre`, `description`, `lieu`, `date_debut`.
- `date_fin` — à prévoir si les événements ont une durée.
- `capacite_max` — à ajouter si les places sont limitées, comme le suggère la maquette.
- `statut_publication` — par exemple `brouillon`, `en_attente_validation`, `publie`, `annule`.
- La décision administrative est conservée dans `VALIDATION`, et non répétée dans un deuxième statut de validation ici.

### `INSCRIPTION`
- `id_inscription` — clé primaire.
- `id_utilisateur` — clé étrangère vers `UTILISATEUR.id_utilisateur`.
- `id_evenement` — clé étrangère vers `EVENEMENT.id_evenement`.
- `date_inscription`.
- `statut_presence` — par exemple `a_confirmer`, `present`, `absent`, afin de distinguer une inscription d’une participation réellement constatée.
- Règle : la paire (`id_utilisateur`, `id_evenement`) doit être unique, pour empêcher les doublons d’inscription.

### `CLUB`
- `id_club` — clé primaire.
- `nom`, `description`.
- Ajouter `tarif_adhesion` ou d’autres informations de cotisation uniquement si ces règles sont confirmées.

### `ADHESION`
- `id_adhesion` — clé primaire.
- `id_utilisateur` — clé étrangère vers `UTILISATEUR.id_utilisateur`.
- `id_club` — clé étrangère vers `CLUB.id_club`.
- `date_adhesion`.
- `statut` — à ajouter seulement si une adhésion peut être demandée, approuvée, refusée ou arrêtée.
- Règle : la paire (`id_utilisateur`, `id_club`) doit être unique si une personne ne peut adhérer qu’une fois à un club. Si les adhésions se renouvellent par année, ajouter l’année ou la période à cette règle d’unicité.

### `VALIDATION`
- `id_validation` — clé primaire.
- `id_evenement` — clé étrangère vers `EVENEMENT.id_evenement`.
- `id_admin` — clé étrangère vers `UTILISATEUR.id_utilisateur` ; cette personne doit avoir le rôle `administration`.
- `statut` — `en_attente`, `valide` ou `refuse`.
- `date_demande`, `date_decision`, `commentaire`.
- Règle : préciser si un événement peut avoir plusieurs demandes successives. Pour une demande unique, imposer une seule validation par événement ; pour des réexamens, conserver plusieurs demandes datées.

### `AFFICHE_IA`
- `id_affiche` — clé primaire.
- `id_evenement` — clé étrangère vers `EVENEMENT.id_evenement`.
- `url_image` — adresse de l’image générée.
- `date_creation`.
- `id_validateur` — clé étrangère facultative vers `UTILISATEUR.id_utilisateur`, vide tant que personne n’a vérifié l’affiche.
- `statut_validation` — par exemple `a_verifier`, `validee`, `refusee`.
- Une affiche est liée à un événement ; un événement peut avoir plusieurs versions d’affiche si l’équipe souhaite garder l’historique.

## 2. Liens et cardinalités

- Un utilisateur BDE peut créer zéro ou plusieurs événements ; chaque événement a un créateur.
- Un utilisateur étudiant peut avoir zéro ou plusieurs inscriptions ; chaque inscription concerne un seul étudiant et un seul événement.
- Un événement peut avoir zéro ou plusieurs inscriptions. Une même personne ne peut s’inscrire qu’une fois au même événement.
- Les étudiants et les clubs sont liés par `ADHESION` : un étudiant peut adhérer à plusieurs clubs et un club peut avoir plusieurs adhérents.
- Une demande de validation concerne un événement et est traitée par un administrateur. Le nombre de demandes successives par événement reste à décider.
- Une affiche concerne un événement et peut être validée par un membre autorisé du BDE.

## 3. Couverture des fonctions du backlog

| Fonction | Données nécessaires | Couverture proposée |
|---|---|---|
| Consulter le portail et le planning (US01–US02) | Événements publiés et clubs | `EVENEMENT`, `CLUB` ; la liste est obtenue en recherchant les événements publiés. |
| S’inscrire à un événement (US03) | Étudiant, événement, date d’inscription | `INSCRIPTION` avec unicité étudiant–événement. |
| Adhérer à un club (US04) | Étudiant, club, date d’adhésion | `ADHESION` avec unicité étudiant–club, selon la règle de renouvellement. |
| Recevoir une confirmation (US05) | Adresse e-mail et inscription/adhésion | Le message peut être envoyé par le système sans table supplémentaire. Une table d’historique n’est nécessaire que si l’on veut enregistrer les envois. |
| Créer et publier un événement (US06, US11) | Détails, créateur, état de publication | `EVENEMENT`. |
| Soumettre et traiter une validation (US07–US10) | Événement, demande, administrateur, décision | `VALIDATION` et état de publication de `EVENEMENT`. Le système devra appliquer la règle des événements après 18 h. |
| Suivre les inscriptions (US12) | Inscriptions liées à un événement | `INSCRIPTION` ; le nombre peut être calculé, sans le recopier dans une autre table. |
| Faire le bilan de participation (US13) | Présence réelle | `INSCRIPTION.statut_presence` permet de distinguer inscrit, présent et absent. |
| Consulter les statistiques (US14) | Inscriptions et présences | Les chiffres peuvent être calculés à partir de `INSCRIPTION`, sans table statistique redondante. |
| Générer une affiche par IA (IA-01) | Image, événement, responsable, décision de vérification | `AFFICHE_IA`. La production de l’image elle-même relève d’un service applicatif, pas uniquement de la base de données. |

## 4. Points à décider avant de figer le modèle

1. Les inscriptions aux événements sont-elles gratuites, ou faut-il gérer prix, paiement et billets ? Le schéma proposé ne stocke pas de paiement faute de règles définies.
2. Les événements ont-ils toujours une capacité maximale ? La maquette l’indique, mais les documents ne précisent pas si cette limite s’applique partout.
3. Les adhésions aux clubs se renouvellent-elles chaque année, et peuvent-elles être payantes ou soumises à approbation ?
4. Une validation peut-elle être redemandée après un refus ? Cela détermine si `VALIDATION` accepte une ou plusieurs demandes par événement.
5. Le suivi de présence doit-il rester un simple état sur l’inscription ou faut-il enregistrer qui a contrôlé la présence et à quel moment ?

## 5. Règles de prudence

- Les clés étrangères doivent empêcher de créer une inscription, une adhésion, une validation ou une affiche liée à un élément inexistant.
- Les noms et rôles des colonnes sont des propositions cohérentes à harmoniser lors de la création réelle de la base.
- Les notifications peuvent être envoyées sans les enregistrer dans une table ; les statistiques simples peuvent être calculées à la demande.
- Le rôle des utilisateurs référencés dans `INSCRIPTION`, `ADHESION`, `VALIDATION` et `AFFICHE_IA` doit être contrôlé par le système : étudiant pour l’inscription et l’adhésion, administration pour la décision, BDE autorisé pour la création et la validation d’affiche.
