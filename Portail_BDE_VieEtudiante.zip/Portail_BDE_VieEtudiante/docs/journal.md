# Journal du projet

## 2026-10-01
- **Fait :** création de ce journal après accord de l’utilisatrice, pour consigner les étapes du projet.
- **Fait :** ajout dans les consignes Copilot des liens vers les documents de référence et de l’obligation de mettre à jour ce journal après chaque étape.
- **Fait :** création de l’agent de workspace « Développeur » dans `.github/agents/Developpeur.agent.md`, après validation de son contenu par l’utilisatrice.
- **Fait :** lecture complète des user stories US01–US14 et IA-01 ; ajout d’une migration Supabase pour profils/roles, demande et décision d’approbation, capacité obligatoire, inscription unique avec contrôle de capacité, suivi de présence et publication temps réel des inscriptions. Règle retenue d’après la réponse : l’heure de début locale, avec validation dès 18 h inclus.
- **Fait :** ajout des écrans de connexion/inscription étudiant, liste et inscription aux événements, création et suivi d’événements côté BDE, demandes d’approbation et statistiques côté administration, et saisie des présences. Règle confirmée : début à 18 h ou après exige une validation ; la capacité est obligatoire ; les paiements de cotisation sont effectués hors portail.
- **Fait :** ajout des cotisations (200 MAD/an ou 300 MAD pour le cycle Prépa/Ingénieur), confirmation manuelle du paiement par le BDE, et parcours d’affiche Gemini avec validation humaine et clé conservée côté fonction Supabase. Le seed couvre une cotisation à confirmer. Mise à jour du README ; sauvegardes de fichiers existants conservées dans `_sauvegardes/`.
- **Vérifié :** `npm.cmd run build` réussit ; l’application locale répond HTTP 200. Les scripts SQL et la fonction Gemini n’ont pas été exécutés sur un projet Supabase, car il n’est pas configuré ; la CLI Supabase et la clé Gemini ne sont pas présentes.
- **Reste à faire :** déployer les trois migrations, le seed et la fonction Edge dans un projet Supabase ; créer/promouvoir les comptes de test et tester les rôles dans le navigateur. La confirmation d’inscription par courriel n’est pas configurée : seul le message à l’écran est disponible, aucun fournisseur de courriel n’a été choisi.

## 2026-10-09
- **Fait :** remplacement du point d’entrée client par une API locale SQLite, avec conservation du wireframe et des écrans existants.
- **Fait :** le serveur local a été mis en place avec les comptes de démonstration et le stockage des données dans `data/portail-bde.sqlite`.
- **Vérifié :** `npm.cmd run build` a réussi et le serveur a démarré localement sur http://127.0.0.1:5173/ avec le message “Portail BDE prêt”.
- **Reste à faire :** tester précisément le parcours complet dans le navigateur avec les comptes de démonstration, puis valider la génération Gemini quand une clé est ajoutée dans le fichier local `.env.local`.
