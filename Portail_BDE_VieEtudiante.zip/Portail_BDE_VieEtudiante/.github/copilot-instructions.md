# Consignes du projet — Portail BDE / Vie étudiante

## Description de l’application

Le portail rassemble les informations sur la vie étudiante de l’EIGSI.
Les étudiants consultent les événements et peuvent s’y inscrire.
Le BDE crée et publie les événements, puis suit les inscriptions.
L’administration approuve ou refuse les événements qui le nécessitent, notamment selon la règle des 18 h.
Les adhésions aux clubs, les statistiques, les confirmations par courriel et les affiches IA sont des évolutions possibles, hors du premier MVP.

## Stack technique

- **Interface :** React avec Vite.
- **Base de données et authentification :** PostgreSQL et Supabase hébergé ; utiliser Supabase Auth si l’authentification est requise.
- **Serveur :** Node.js/Express est reporté après le MVP, sauf besoin confirmé.
- **Styles :** CSS simple au départ ; Tailwind seulement s’il est déjà configuré ou demandé.
- **Sécurité :** protéger les rôles et les données avec les règles d’accès Supabase (RLS). Ne jamais mettre une clé secrète de service dans le code du navigateur.
- **Outils connus :** Node.js et npm. Vérifier leur présence et leur version avant de proposer une installation. Ne pas supposer que Git est installé.

## Structure des dossiers

### Structure actuelle

- `.github/copilot-instructions.md` — présentes consignes du projet.
- `docs/00-resume-projet.md` — résumé, inventaire et questions ouvertes.
- `docs/01-schema-corrige.md` — proposition de modèle de données.
- `docs/02-mvp.md` — périmètre et étapes du MVP.
- `docs/journal.md` — journal des étapes du projet ; le créer s’il n’existe pas.
- Les rapports PDF, le diagramme BPMN, le MCD, les wireframes et l’image de choix de stack sont à la racine du projet.
- Le projet ne contient pas encore de code applicatif.

### Documents de référence

- [Résumé du projet](../docs/00-resume-projet.md)
- [Schéma corrigé](../docs/01-schema-corrige.md)
- [Périmètre du MVP](../docs/02-mvp.md)

### Organisation suggérée quand le code commencera

- `src/` — code de l’interface React.
- `src/components/` — éléments d’interface réutilisables.
- `src/pages/` — écrans du portail, si plusieurs écrans le justifient.
- `src/lib/` — connexion à Supabase et fonctions partagées.
- `supabase/migrations/` — scripts SQL de création ou d’évolution de la base, s’ils deviennent nécessaires.

Créer uniquement les dossiers utiles, après accord de l’utilisatrice. Ne pas présenter cette organisation suggérée comme déjà existante.

## Règles de travail

- Avant toute modification de fichier, proposer un **plan court** en langage simple et attendre le « OK » explicite de l’utilisatrice.
- Avancer par petites étapes ; après chaque étape, expliquer simplement ce qui a changé et vérifier le résultat lorsque c’est possible.
- Après chaque étape de travail, mettre à jour [le journal du projet](../docs/journal.md) avec la date, ce qui a été fait et ce qui reste à faire. Créer le journal s’il n’existe pas.
- Ne jamais supprimer de fichier. Ne jamais installer un outil ou une dépendance sans demander l’accord au préalable.
- Avant une modification importante d’un fichier existant, en créer une copie dans `_sauvegardes/` et conserver l’original. Demander confirmation si la copie n’est pas possible ou si le périmètre de la modification est incertain.
- Expliquer les erreurs et les solutions possibles en français simple, sans supposer que l’utilisatrice sait coder.
- Écrire des commentaires clairs et utiles dans le code, en français lorsque cela convient ; éviter les commentaires qui répètent simplement la ligne de code.
- Ne pas modifier, déplacer ni supprimer les documents de conception d’origine sans autorisation explicite.
- Ne pas inventer les règles métier manquantes. Signaler les questions ouvertes, notamment la limite des 18 h, la capacité des événements et les éventuels paiements.
