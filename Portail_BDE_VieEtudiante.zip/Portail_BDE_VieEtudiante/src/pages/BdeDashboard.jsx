import { useCallback, useEffect, useState } from 'react';
import {
  confirmMembershipPayment,
  createEvent,
  decidePoster,
  generateEventPoster,
  getBdeEvents,
  getBdePosters,
  getEventRegistrations,
  getPendingMemberships,
  getPosterPreview,
  setAttendance,
} from '../lib/portalData.js';
import './Portal.css';

const dateFormatter = new Intl.DateTimeFormat('fr-FR', {
  dateStyle: 'medium',
  timeStyle: 'short',
  timeZone: 'Europe/Paris',
});

const statusLabels = {
  brouillon: 'Brouillon',
  en_attente_validation: 'En attente de validation',
  publie: 'Publié',
  refuse: 'Refusé',
  annule: 'Annulé',
};

export default function BdeDashboard({ profile }) {
  const [events, setEvents] = useState([]);
  const [selectedEventId, setSelectedEventId] = useState('');
  const [registrations, setRegistrations] = useState([]);
  const [pendingMemberships, setPendingMemberships] = useState([]);
  const [posters, setPosters] = useState([]);
  const [posterPreviews, setPosterPreviews] = useState({});
  const [feedback, setFeedback] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  const loadEvents = useCallback(async () => {
    try {
      const rows = await getBdeEvents();
      setEvents(rows);
      setSelectedEventId((current) => current || String(rows[0]?.id_evenement ?? ''));
    } catch {
      setError('Impossible de charger tes événements. Vérifie ton rôle BDE et le serveur local.');
    }
  }, []);

  const loadRegistrations = useCallback(async (eventId) => {
    if (!eventId) { setRegistrations([]); return; }
    try {
      setRegistrations(await getEventRegistrations(eventId));
      setError('');
    } catch {
      setError('Impossible de charger les inscriptions de cet événement.');
    }
  }, []);

  const loadMemberships = useCallback(async () => {
    try { setPendingMemberships(await getPendingMemberships()); }
    catch { setError('Impossible de charger les cotisations à confirmer.'); }
  }, []);

  const loadPosters = useCallback(async () => {
    try {
      const rows = await getBdePosters();
      setPosters(rows);
      const previews = await Promise.all(rows.map(async (poster) => [poster.id_affiche, await getPosterPreview(poster.id_affiche)]));
      setPosterPreviews(Object.fromEntries(previews));
    } catch {
      setError('Impossible de charger les affiches générées.');
    }
  }, []);

  useEffect(() => { loadEvents(); loadMemberships(); loadPosters(); }, [loadEvents, loadMemberships, loadPosters]);
  useEffect(() => { loadRegistrations(selectedEventId); }, [loadRegistrations, selectedEventId]);
  useEffect(() => {
    if (!selectedEventId) return undefined;
    const timer = window.setInterval(() => loadRegistrations(selectedEventId), 4000);
    return () => window.clearInterval(timer);
  }, [loadRegistrations, selectedEventId]);

  async function handleCreateEvent(event) {
    event.preventDefault();
    const form = event.currentTarget;
    const formData = new FormData(form);
    setFeedback(''); setError(''); setBusy(true);
    try {
      await createEvent({
        titre: String(formData.get('titre')).trim(),
        description: String(formData.get('description')).trim(),
        lieu: String(formData.get('lieu')).trim(),
        date_debut: new Date(String(formData.get('date_debut'))).toISOString(),
        date_fin: formData.get('date_fin') ? new Date(String(formData.get('date_fin'))).toISOString() : null,
        capacite_max: Number(formData.get('capacite_max')),
      });
      form.reset();
      setFeedback('Événement enregistré. Un début à 18 h ou après envoie la demande à l’administration ; sinon, l’événement est publié.');
      await loadEvents();
    } catch (requestError) {
      setError(requestError.message || 'La création a échoué. Vérifie les champs.');
    } finally { setBusy(false); }
  }

  async function handleAttendance(registrationId, status) {
    setError('');
    try { await setAttendance(registrationId, status); await loadRegistrations(selectedEventId); }
    catch (requestError) { setError(requestError.message || 'La présence n’a pas pu être mise à jour.'); }
  }

  async function handlePaymentConfirmation(membershipId) {
    try {
      await confirmMembershipPayment(membershipId);
      setFeedback('Cotisation marquée comme réglée et adhésion activée.');
      await loadMemberships();
    } catch (requestError) {
      setError(requestError.message || 'Vérifie d’abord que le règlement a bien été reçu hors du portail.');
    }
  }

  async function handlePosterGeneration(event) {
    event.preventDefault();
    const form = event.currentTarget;
    const values = new FormData(form);
    setFeedback(''); setError(''); setBusy(true);
    try {
      await generateEventPoster(values.get('event_id'), String(values.get('prompt')).trim());
      form.reset();
      setFeedback('Affiche créée et mise en attente de validation ; elle n’est pas encore publique.');
      await loadPosters();
    } catch (requestError) {
      setError(requestError.message || 'Génération impossible. Vérifie GEMINI_API_KEY dans .env.local.');
    } finally { setBusy(false); }
  }

  async function handlePosterDecision(posterId, decision) {
    try {
      await decidePoster(posterId, decision);
      setFeedback(decision === 'validee' ? 'Affiche approuvée.' : 'Affiche refusée.');
      await loadPosters();
      await loadEvents();
    } catch (requestError) { setError(requestError.message || 'La décision sur l’affiche a échoué.'); }
  }

  const selectedEvent = events.find((event) => String(event.id_evenement) === String(selectedEventId));

  return (
    <>
      <div className="portal-columns">
        <section className="portal-panel">
          <div className="portal-panel__heading"><div><p className="portal-eyebrow">ESPACE BDE</p><h2>Créer un événement</h2></div></div>
          <form className="portal-form" onSubmit={handleCreateEvent}>
            <label>Titre<input name="titre" required maxLength="140" /></label>
            <label>Description<textarea name="description" /></label>
            <div className="portal-form__row">
              <label>Début<input name="date_debut" type="datetime-local" required /></label>
              <label>Fin (facultatif)<input name="date_fin" type="datetime-local" /></label>
            </div>
            <div className="portal-form__row">
              <label>Lieu<input name="lieu" required /></label>
              <label>Places maximum<input name="capacite_max" type="number" min="1" step="1" required /></label>
            </div>
            <button className="button button--primary" disabled={busy} type="submit">{busy ? 'Enregistrement…' : 'Créer / soumettre'}</button>
          </form>
          {feedback && <p className="portal-feedback" role="status">{feedback}</p>}
          {error && <p className="portal-feedback portal-feedback--error" role="alert">{error}</p>}
        </section>

        <section className="portal-panel">
          <div className="portal-panel__heading">
            <div><p className="portal-eyebrow">MES ÉVÉNEMENTS</p><h2>Suivre les inscriptions</h2></div>
            <button className="button button--quiet" type="button" onClick={() => loadRegistrations(selectedEventId)}>Actualiser</button>
          </div>
          {events.length === 0 ? <p className="portal-empty">Tu n’as pas encore créé d’événement.</p> : <>
            <label className="portal-form">Choisir un événement
              <select className="portal-select" value={selectedEventId} onChange={(event) => setSelectedEventId(event.target.value)}>
                {events.map((item) => <option key={item.id_evenement} value={item.id_evenement}>{item.titre} — {statusLabels[item.statut_publication] ?? item.statut_publication}</option>)}
              </select>
            </label>
            {selectedEvent && <p className="portal-empty">{dateFormatter.format(new Date(selectedEvent.date_debut))} · {registrations.length} / {selectedEvent.capacite_max} inscrits (actualisé automatiquement)</p>}
            <div className="portal-list">
              {registrations.map((registration) => <div className="portal-row" key={registration.id_inscription}>
                <div>
                  <strong>{registration.utilisateur?.prenom} {registration.utilisateur?.nom}</strong>
                  <p>{registration.utilisateur?.email}</p>
                  <span className={`portal-status ${registration.statut_presence === 'present' ? 'portal-status--good' : registration.statut_presence === 'a_confirmer' ? 'portal-status--pending' : ''}`}>
                    {registration.statut_presence === 'present' ? 'Présent' : registration.statut_presence === 'absent' ? 'Absent' : 'Présence à confirmer'}
                  </span>
                </div>
                <div className="portal-row__actions">
                  <button className="button button--approve button--small" type="button" onClick={() => handleAttendance(registration.id_inscription, 'present')}>Présent</button>
                  <button className="button button--quiet button--small" type="button" onClick={() => handleAttendance(registration.id_inscription, 'absent')}>Absent</button>
                </div>
              </div>)}
              {registrations.length === 0 && <p className="portal-empty">Aucune inscription pour cet événement.</p>}
            </div>
          </>}
        </section>
      </div>

      <section className="portal-panel">
        <div className="portal-panel__heading"><div><p className="portal-eyebrow">COTISATIONS CLUBS</p><h2>Paiements à confirmer</h2></div><button className="button button--quiet" type="button" onClick={loadMemberships}>Actualiser</button></div>
        <p className="portal-empty">Confirme uniquement les paiements reçus hors du portail. Année : 200 MAD · Cycle Prépa ou Ingénieur : 300 MAD.</p>
        <div className="portal-list">
          {pendingMemberships.map((membership) => <div className="portal-row" key={membership.id_adhesion}>
            <div><strong>{membership.utilisateur?.prenom} {membership.utilisateur?.nom} · {membership.club?.nom}</strong><p>{membership.montant_mad} MAD · {membership.plan_cotisation === 'annuelle' ? `Année ${membership.annee_academique}` : `Cycle ${membership.cycle_etude === 'prepa' ? 'Prépa' : 'Ingénieur'}`}</p></div>
            <button className="button button--approve button--small" type="button" onClick={() => handlePaymentConfirmation(membership.id_adhesion)}>Confirmer le paiement reçu</button>
          </div>)}
          {pendingMemberships.length === 0 && <p className="portal-empty">Aucun paiement à confirmer.</p>}
        </div>
      </section>

      <section className="portal-panel">
        <div className="portal-panel__heading"><div><p className="portal-eyebrow">CRÉATION ASSISTÉE</p><h2>Affiche d’événement avec Gemini</h2></div></div>
        <form className="portal-form poster-form" onSubmit={handlePosterGeneration}>
          <label>Événement<select name="event_id" required defaultValue=""><option value="" disabled>Choisis un événement que tu as créé</option>{events.map((event) => <option key={event.id_evenement} value={event.id_evenement}>{event.titre}</option>)}</select></label>
          <label>Décris le style de l’affiche<textarea name="prompt" minLength="10" maxLength="1500" required placeholder="Exemple : couleurs joyeuses, ambiance étudiante et bord de mer, illustration moderne…" /></label>
          <button className="button button--primary" type="submit" disabled={busy}>{busy ? 'Génération en cours…' : 'Générer une affiche'}</button>
        </form>
        <p className="portal-empty">La clé Gemini reste sur le serveur local. Toute affiche générée reste privée jusqu’à validation.</p>
        <div className="portal-list">
          {posters.map((poster) => <article className="portal-row" key={poster.id_affiche}>
            <div><strong>{poster.evenement?.titre}</strong><p>État : {poster.statut_validation === 'validee' ? 'Validée' : poster.statut_validation === 'refusee' ? 'Refusée' : 'À vérifier'}</p>
              {posterPreviews[poster.id_affiche] && <img className="poster-preview" src={posterPreviews[poster.id_affiche]} alt={`Affiche proposée pour ${poster.evenement?.titre}`} />}
            </div>
            {poster.statut_validation === 'a_verifier' && <div className="portal-row__actions">
              <button className="button button--approve button--small" type="button" onClick={() => handlePosterDecision(poster.id_affiche, 'validee')}>Valider</button>
              <button className="button button--reject button--small" type="button" onClick={() => handlePosterDecision(poster.id_affiche, 'refusee')}>Refuser</button>
            </div>}
          </article>)}
          {posters.length === 0 && <p className="portal-empty">Aucune affiche générée pour le moment.</p>}
        </div>
      </section>
    </>
  );
}
