export default function Hello() {
  return (
    <main className="welcome-card">
      <span className="welcome-card__eyebrow">PORTAIL BDE · VIE ÉTUDIANTE</span>
      <h1>Hello 👋</h1>
      <p>Votre espace de vie étudiante est en préparation.</p>
    </main>
  );
}
