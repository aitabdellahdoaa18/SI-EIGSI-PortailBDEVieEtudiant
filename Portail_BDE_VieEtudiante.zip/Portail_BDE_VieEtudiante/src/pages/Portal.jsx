import { useEffect, useState } from 'react';
import AuthPanel from '../components/AuthPanel.jsx';
import ClubMembership from '../components/ClubMembership.jsx';
import { getCurrentUser, signOut } from '../lib/portalData.js';
import AdminDashboard from './AdminDashboard.jsx';
import BdeDashboard from './BdeDashboard.jsx';
import Events from './Events.jsx';
import './Portal.css';

const roleLabels = {
  etudiant: 'Espace étudiant',
  bde: 'Espace BDE',
  administration: 'Espace administration',
};

export default function Portal() {
  const [profile, setProfile] = useState(null);
  const [profileError, setProfileError] = useState('');
  const [activeView, setActiveView] = useState('evenements');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let mounted = true;
    getCurrentUser()
      .then((user) => { if (mounted) setProfile(user); })
      .catch(() => { if (mounted) setProfileError('Impossible de joindre le serveur local. Vérifie qu’il est démarré.'); })
      .finally(() => { if (mounted) setLoading(false); });
    return () => { mounted = false; };
  }, []);

  async function handleSignOut() {
    try {
      await signOut();
      setProfile(null);
      setProfileError('');
      setActiveView('evenements');
    } catch {
      setProfileError('La déconnexion a échoué. Réessaie.');
    }
  }

  if (loading) {
    return <main className="portal-shell"><p className="events-message">Vérification de la session…</p></main>;
  }

  const role = profile?.role;
  const availableViews = role === 'bde'
    ? [['evenements', 'Événements'], ['gestion-bde', 'Gestion BDE']]
    : role === 'administration'
      ? [['evenements', 'Événements'], ['administration', 'Demandes et statistiques']]
      : [['evenements', 'Événements'], ['clubs', 'Adhésions clubs']];

  return (
    <main className="portal-shell">
      <header className="portal-topbar">
        <a className="portal-brand" href="#evenements" onClick={() => setActiveView('evenements')}>EIGSI · PORTAIL BDE</a>
        {profile ? (
          <div className="portal-topbar__account">
            <span className="portal-user">{profile.prenom} {profile.nom} · {roleLabels[role]}</span>
            <button className="button button--quiet button--small" type="button" onClick={handleSignOut}>Déconnexion</button>
          </div>
        ) : <span className="portal-user">Bienvenue</span>}
      </header>

      {profile && (
        <nav className="portal-tabs" aria-label="Navigation principale">
          {availableViews.map(([view, label]) => (
            <button
              className="portal-tab"
              type="button"
              aria-current={activeView === view ? 'page' : undefined}
              key={view}
              onClick={() => setActiveView(view)}
            >
              {label}
            </button>
          ))}
        </nav>
      )}

      {profileError && <p className="portal-feedback portal-feedback--error" role="alert">{profileError}</p>}
      {activeView === 'evenements' && <Events profile={profile} />}
      {activeView === 'clubs' && role === 'etudiant' && <ClubMembership />}
      {activeView === 'gestion-bde' && role === 'bde' && <BdeDashboard profile={profile} />}
      {activeView === 'administration' && role === 'administration' && <AdminDashboard />}
      {!profile && !profileError && <AuthPanel onAuthenticated={(user) => { setProfile(user); setActiveView('evenements'); }} />}
    </main>
  );
}
