import { useEffect, useState } from 'react';
import { getPublicEvents, registerForEvent } from '../lib/portalData.js';
import './Events.css';

const dateFormatter = new Intl.DateTimeFormat('fr-FR', {
  dateStyle: 'full',
  timeStyle: 'short',
  timeZone: 'Europe/Paris',
});

export default function Events({ profile }) {
  const [events, setEvents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [feedback, setFeedback] = useState('');
  const [registering, setRegistering] = useState(null);

  async function loadEvents() {
    try {
      setEvents(await getPublicEvents());
      setError('');
    } catch {
      setError('Impossible de charger les événements. Vérifie que le serveur local fonctionne.');
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { loadEvents(); }, []);

  async function handleRegister(eventId) {
    setFeedback('');
    setError('');
    setRegistering(eventId);
    try {
      await registerForEvent(eventId);
      setFeedback('Inscription enregistrée. Tu es bien inscrit à cet événement.');
      await loadEvents();
    } catch (registrationError) {
      setError(registrationError.message?.includes('capacité')
        ? 'Cet événement a atteint sa capacité maximale.'
        : registrationError.message?.includes('déjà inscrit')
          ? 'Tu es déjà inscrit à cet événement.'
          : registrationError.message || 'L’inscription a échoué. Réessaie.');
    } finally {
      setRegistering(null);
    }
  }

  return (
    <main className="events-page">
      <header className="events-header">
        <div>
          <span className="events-eyebrow">EIGSI · VIE ÉTUDIANTE</span>
          <h1>Les prochains rendez-vous</h1>
          <p>Découvre les événements proposés par le BDE.</p>
        </div>
        <span className="events-mark" aria-hidden="true">BDE</span>
      </header>

      {loading && <p className="events-message" role="status">Chargement des événements…</p>}
      {error && <p className="events-message events-message--error" role="alert">{error}</p>}
      {feedback && <p className="events-message" role="status">{feedback}</p>}
      {!loading && !error && events.length === 0 && <p className="events-message">Aucun événement publié pour le moment.</p>}

      <section className="events-grid" aria-label="Événements publiés">
        {events.map((event) => (
          <article className="event-card" key={event.id_evenement}>
            <div className="event-card__date">{dateFormatter.format(new Date(event.date_debut))}</div>
            <h2>{event.titre}</h2>
            {event.affiche_approuvee && <img className="poster-preview" src={`/api/posters/${event.affiche_approuvee}/image`} alt={`Affiche officielle pour ${event.titre}`} />}
            <p className="event-card__description">{event.description}</p>
            <div className="event-card__details">
              <span>{event.lieu}</span>
              <span>{event.inscrits} / {event.capacite_max} inscrits</span>
            </div>
            {profile?.role === 'etudiant' && (
              <button className="button button--primary event-card__action" type="button"
                disabled={registering === event.id_evenement || event.inscrits >= event.capacite_max}
                onClick={() => handleRegister(event.id_evenement)}>
                {registering === event.id_evenement ? 'Inscription…' : event.inscrits >= event.capacite_max ? 'Complet' : 'S’inscrire'}
              </button>
            )}
          </article>
        ))}
      </section>
    </main>
  );
}
